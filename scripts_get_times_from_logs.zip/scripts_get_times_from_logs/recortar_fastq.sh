#!/bin/bash

# Ruta a los archivos originales
# INPUT1="/home/natalia/Tesis/Datos/Paper/SRR341725_1.fastq.gz"
# INPUT2="/home/natalia/Tesis/Datos/Paper/SRR341725_2.fastq.gz"
# INPUT1="/home/natalia/Tesis/Datos/galaxy/ERR2231568_1.fastqsanger.gz"
# INPUT2="/home/natalia/Tesis/Datos/galaxy/ERR2231568_2.fastqsanger.gz"

INPUT1="/home/natalia/Tesis/Datos/Pendrive/C1/C1_FKDN220243764-1A_HN3V5DSX3_L3_1.fq.gz"
INPUT2="/home/natalia/Tesis/Datos/Pendrive/C1/C1_FKDN220243764-1A_HN3V5DSX3_L3_2.fq.gz"

# Cantidad de lecturas a conservar
NUM_READS="${1:-300}"

# Línea total = 4 líneas por lectura
NUM_LINES=$((NUM_READS * 4))

# Archivos de salida
OUT1="/home/natalia/Tesis/Datos/Recortados/mini1.fastq"
OUT2="/home/natalia/Tesis/Datos/Recortados/mini2.fastq"

# Crear archivos recortados
zcat "$INPUT1" | head -n "$NUM_LINES" > "$OUT1"
zcat "$INPUT2" | head -n "$NUM_LINES" > "$OUT2"

# Comprimirlos nuevamente si querés
gzip -f "$OUT1"
gzip -f "$OUT2"

echo "✅ Archivos recortados: mini1.fastq.gz y mini2.fastq.gz (${NUM_READS} lecturas cada uno)"

