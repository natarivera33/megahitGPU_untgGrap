import re
import csv
from dataclasses import dataclass
from typing import List, Dict

FLOAT_RE = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"

@dataclass
class PatternStat:
    pattern: str
    count: int = 0
    total_seconds: float = 0.0
    no_time_count: int = 0

def read_patterns_file(path: str) -> List[str]:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = [ln.rstrip("\n") for ln in f if ln.strip() != ""]

    if not lines:
        raise ValueError("El archivo de patrones está vacío.")

    m = re.match(r"^\s*CANTIDAD_LINEAS\s*=\s*(\d+)\s*$", lines[0])
    if not m:
        raise ValueError("La primera línea debe ser tipo: CANTIDAD_LINEAS=21")

    n = int(m.group(1))
    patterns = [ln.strip() for ln in lines[1:]]

    if len(patterns) < n:
        raise ValueError(f"Se esperaban {n} patrones, pero encontré {len(patterns)}.")

    return patterns[:n]

def compile_extractor_for(pattern: str) -> re.Pattern:
    pat = re.escape(pattern)
    regex = rf"{pat}\s*,?\s*({FLOAT_RE})\s*(?:'|\bseconds\b)?"
    return re.compile(regex)

def process_log(log_path: str, patterns: List[str]) -> Dict[str, PatternStat]:
    stats: Dict[str, PatternStat] = {p: PatternStat(pattern=p) for p in patterns}
    extractors = {p: compile_extractor_for(p) for p in patterns}

    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            for p in patterns:
                if p in line:
                    m = extractors[p].search(line)
                    if m:
                        stats[p].count += 1
                        stats[p].total_seconds += float(m.group(1))
                    else:
                        stats[p].no_time_count += 1
    return stats

def write_csv(stats: Dict[str, PatternStat], csv_path: str) -> None:
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "patron",
            "cantidad_lineas",
            "tiempo_total_segundos",
            "lineas_sin_tiempo"
        ])

        for s in stats.values():
            writer.writerow([
                s.pattern,
                s.count,
                f"{s.total_seconds:.6f}",
                s.no_time_count
            ])

def print_report(stats: Dict[str, PatternStat]) -> None:
    ordered = sorted(stats.values(), key=lambda s: s.total_seconds, reverse=True)

    print("=== REPORTE POR PATRON ===")
    for s in ordered:
        print(f"- {s.pattern}")
        print(f"  lineas sumadas: {s.count}")
        if s.no_time_count:
            print(f"  lineas SIN tiempo detectable: {s.no_time_count}")
        print(f"  total: {s.total_seconds:.6f} s\n")

    total = sum(s.total_seconds for s in ordered)
    print(f"TIEMPO TOTAL GLOBAL: {total:.6f} s")

import sys
import os

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Uso:")
        print("  python sumar_tiempos.py <log_path> <patrones_path> [csv_salida]")
        sys.exit(1)

    log_path = sys.argv[1]
    patterns_path = sys.argv[2]

    if len(sys.argv) >= 4:
        csv_out = sys.argv[3]
    else:
        base_log = os.path.basename(log_path)
        dir_log = os.path.dirname(log_path)

        if dir_log:
            dir_clean = dir_log.replace("/", "_").replace(".", "")
            csv_out = f"resumen_{dir_clean}_{base_log}.csv"
        else:
            csv_out = f"resumen_{base_log}.csv"

    patterns = read_patterns_file(patterns_path)
    stats = process_log(log_path, patterns)

    print_report(stats)
    write_csv(stats, csv_out)

    print(f"\nCSV generado: {csv_out}")

