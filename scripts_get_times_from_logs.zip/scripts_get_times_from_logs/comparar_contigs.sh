#!/bin/bash

if [ "$#" -ne 2 ]; then
  echo "Uso: $0 archivo1.fa archivo2.fa"
  exit 1
fi

A1="$1"
A2="$2"

# Archivos temporales
TMP1=$(mktemp)
TMP2=$(mktemp)

# Extraer secuencias sin encabezados, una por línea
awk '/^>/{if(seq) print seq; seq=""; next} {seq=seq $0} END{if(seq) print seq}' "$A1" | sort > "$TMP1"
awk '/^>/{if(seq) print seq; seq=""; next} {seq=seq $0} END{if(seq) print seq}' "$A2" | sort > "$TMP2"

# Comparación
COMUNES=$(comm -12 "$TMP1" "$TMP2" | wc -l)
SOLO1=$(comm -23 "$TMP1" "$TMP2" | tee unicos_cpu.txt | wc -l)
SOLO2=$(comm -13 "$TMP1" "$TMP2" | tee unicos_gpu.txt | wc -l)
TOTAL1=$(wc -l < "$TMP1")
TOTAL2=$(wc -l < "$TMP2")

echo "=============================="
echo "Comparación por contenido"
echo "=============================="
echo "Contigs en $A1 : $TOTAL1"
echo "Contigs en $A2 : $TOTAL2"
echo
echo "Contigs idénticos      : $COMUNES"
echo "Contigs únicos en $A1  : $SOLO1 (guardado en unicos_cpu.txt)"
echo "Contigs únicos en $A2  : $SOLO2 (guardado en unicos_gpu.txt)"
echo "=============================="

# Limpieza temporal
rm "$TMP1" "$TMP2"

