//
// Created by vout on 11/19/18..
//

#include "unitig_graph.h"
#include <omp.h>
#include <cmath>
#include <chrono>

#include <cuda_runtime.h>            // cudaMalloc/cudaMemcpy/cudaMemset/cudaFree
#include "assembly/gpu_assembly.cuh" // wrappers host (NO kernels)

#include "kmlib/kmbitvector.h"
#include "utils/mutex.h"
#include "utils/utils.h"

using Clock = std::chrono::high_resolution_clock;



UnitigGraph::UnitigGraph(SDBG *sdbg)
    : sdbg_(sdbg), adapter_impl_(this), sudo_adapter_impl_(this) {

    SimpleTimer timer;

    id_map_.clear();
    vertices_.clear();

    uint64_t numEdges = sdbg->size();
    const size_t MAX_VERTICES = numEdges;
    int blockSize = 256;
    int gridSize  = (numEdges + blockSize - 1) / blockSize;
 
  //  CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));

    timer.reset();
    timer.start();

    
    GPU_procesarCaminosSimples( sdbg->d_isValidEdgeBits,sdbg->d_nextEdge,sdbg->d_prevEdge,sdbg->d_rcEdge,sdbg->d_edgeMultiplicity,numEdges,sdbg->d_count_palindrome,sdbg->d_locks,   sdbg->d_vertices, sdbg->d_vertex_counter,
    blockSize/*, sdbg->stream*/);



// Esperar SOLO este stream antes de usar resultados en CPU
//CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));


 // cudaDeviceSynchronize();
  GPU_checkLastCuda("procesarCaminosSimples");
timer.stop();
xinfo("---GPU---Construccion grafo Unitig---Tiempo kernel hallar caminos simples:{.3}\n", timer.elapsed());

// Copiar resultados a CPU
timer.reset();
timer.start();

unsigned int h_vertex_counter_sp = 0;
CUDA_CHECK(cudaMemcpy/*Async*/(&h_vertex_counter_sp, sdbg->d_vertex_counter,   sizeof(unsigned int),  cudaMemcpyDeviceToHost/*, sdbg->stream*/));
//CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));
std::vector<uint32_t> h_vertices_sp(h_vertex_counter_sp * 6);
CUDA_CHECK(cudaMemcpy/*Async*/(h_vertices_sp.data(),  sdbg->d_vertices, (size_t)h_vertex_counter_sp * 6 * sizeof(uint32_t),  cudaMemcpyDeviceToHost/*,   sdbg->stream*/));
//CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));

timer.stop();
xinfo("---GPU---Construccion grafo Unitig---Tiempo transferencia hacia CPU de resultados caminos simples (cudaMemcpy):{.3}\n", timer.elapsed());

// ================= KERNEL: loops =================
timer.reset();
timer.start();

CUDA_CHECK(cudaMemset/*Async*/(sdbg->d_vertex_counter, 0,  sizeof(unsigned int)/*, sdbg->stream*/));
uint32_t cantMax_v_salida_loop = numEdges;//*(0.17/100);//antes 334
CUDA_CHECK(cudaMemset/*Async*/(sdbg->d_vertices,0,  (size_t)cantMax_v_salida_loop * 6 * sizeof(uint32_t)/*,sdbg->stream*/));
//CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));
  
timer.stop();
xinfo("---GPU---Construccion grafo Unitig---Tiempo transferencia a memoria de GPU (cudaMemcpy y cudaMemset) para hallar loops:{.3}\n", timer.elapsed());

timer.reset();
timer.start();


// wrapper
GPU_procesarLoops(sdbg->d_isValidEdgeBits, sdbg->d_prevEdge,sdbg->d_nextEdge, sdbg->d_rcEdge, sdbg->d_edgeMultiplicity, sdbg->d_locks,numEdges,sdbg->d_vertices, sdbg->d_vertex_counter, blockSize/*, sdbg->stream*/);


  //cudaDeviceSynchronize();
//CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));
GPU_checkLastCuda("procesarLoops");


    timer.stop();
    xinfo("---GPU---Construccion grafo Unitig---Tiempo kernel hallar loops:{.5}\n", timer.elapsed());

    // Copiar resultados a CPU
    timer.reset();
    timer.start();

    unsigned int h_vertex_counter_lp = 0;
  //  cudaMemcpy(&h_vertex_counter_lp, sdbg->d_vertex_counter,  sizeof(unsigned int), cudaMemcpyDeviceToHost);

CUDA_CHECK(cudaMemcpy/*Async*/(&h_vertex_counter_lp,sdbg->d_vertex_counter, sizeof(unsigned int), cudaMemcpyDeviceToHost/*, sdbg->stream*/));
  //  CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));

    std::vector<uint32_t> h_vertices_lp(h_vertex_counter_lp * 6);
  //  cudaMemcpy(h_vertices_lp.data(), sdbg->d_vertices, h_vertex_counter_lp * 7 * sizeof(uint32_t), cudaMemcpyDeviceToHost);
    
    CUDA_CHECK(cudaMemcpy/*Async*/(h_vertices_lp.data(), sdbg->d_vertices,(size_t)h_vertex_counter_lp * 6 * sizeof(uint32_t), cudaMemcpyDeviceToHost/*,sdbg->stream*/));

   // CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));

int h_count_palindrome = 0;
//unsigned int h_vertex_counter = 0;
CUDA_CHECK(cudaMemcpy/*Async*/(&h_count_palindrome,sdbg->d_count_palindrome,sizeof(int), cudaMemcpyDeviceToHost/*, sdbg->stream*/));

   cudaDeviceSynchronize();
    timer.stop();
    xinfo("---GPU---Construccion grafo Unitig---Tiempo transferencia hacia CPU de resultados hallar loops (cudaMemcpy):{.3}\n", timer.elapsed());

//CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));

timer.reset();
timer.start();

// Liberar memoria GPU
CUDA_CHECK(cudaFree/*Async*/(sdbg->d_isValidEdgeBits/*,      sdbg->stream*/));
CUDA_CHECK(cudaFree/*Async*/(sdbg->d_nextEdge/*,         sdbg->stream*/));
CUDA_CHECK(cudaFree/*Async*/(sdbg->d_prevEdge/*,         sdbg->stream*/));
CUDA_CHECK(cudaFree/*Async*/(sdbg->d_rcEdge/*,           sdbg->stream*/));
CUDA_CHECK(cudaFree/*Async*/(sdbg->d_edgeMultiplicity/*, sdbg->stream*/));
CUDA_CHECK(cudaFree/*Async*/(sdbg->d_locks/*,            sdbg->stream*/));
CUDA_CHECK(cudaFree/*Async*/(sdbg->d_count_palindrome/*, sdbg->stream*/));
CUDA_CHECK(cudaFree/*Async*/(sdbg->d_vertices/*,         sdbg->stream*/));
CUDA_CHECK(cudaFree/*Async*/(sdbg->d_vertex_counter/*,   sdbg->stream*/));



sdbg->d_isValidEdgeBits      = nullptr;
sdbg->d_nextEdge         = nullptr;
sdbg->d_prevEdge         = nullptr;
sdbg->d_rcEdge           = nullptr;
sdbg->d_edgeMultiplicity = nullptr;
sdbg->d_locks            = nullptr;
sdbg->d_count_palindrome = nullptr;
sdbg->d_vertices         = nullptr;
sdbg->d_vertex_counter   = nullptr;

//CUDA_CHECK(cudaStreamSynchronize(sdbg->stream));
  //  cudaDeviceSynchronize();

timer.stop();
xinfo("---GPU---Construccion grafo Unitig---Tiempo liberar memoria de GPU (cudaFree):{.3}\n", timer.elapsed());



	timer.reset();
	timer.start();
	
	unsigned int h_vertex_counter = 0;   
	h_vertex_counter = h_vertex_counter_sp + h_vertex_counter_lp;   
	// Traducir a vertices_
	vertices_.clear();
	int max_largo_sp = 0;
        int max_largo_loop = 0;
	//if (h_vertex_counter_sp+h_vertex_counter_lp >= kMaxNumVertices) {
	if (h_vertex_counter>= kMaxNumVertices) {
		xfatal(
		"Too many vertices in the unitig graph ({} >= {}), "
		"you may increase the kmer size to remove tons of erroneous kmers.\n",
		vertices_.size(), kMaxNumVertices);
	}

	sdbg_->FreeMultiplicity();
//	id_map_.reserve((h_vertex_counter_sp+h_vertex_counter_lp)* 2 - h_count_palindrome);
	id_map_.reserve((h_vertex_counter)* 2 - h_count_palindrome);

	//for (uint32_t i = 0; i < h_vertex_counter_sp+h_vertex_counter_lp; i++) {
	for (uint32_t i = 0; i < h_vertex_counter; i++) {
	
		if (i < h_vertex_counter_sp){
			vertices_.emplace_back(
				h_vertices_sp[i * 6 + 0], h_vertices_sp[i * 6 + 1],
				h_vertices_sp[i * 6 + 2], h_vertices_sp[i * 6 + 3],
				h_vertices_sp[i * 6 + 4], h_vertices_sp[i * 6 + 5],
				false
			);
		
			if (h_vertices_sp[i * 6 + 5] > max_largo_sp) 
				max_largo_sp=h_vertices_sp[i * 6 + 5];
		}
		else {
			vertices_.emplace_back(
			h_vertices_lp[(i-h_vertex_counter_sp) * 6 + 0], h_vertices_lp[(i-h_vertex_counter_sp) * 6 + 1],
			h_vertices_lp[(i-h_vertex_counter_sp) * 6 + 2], h_vertices_lp[(i-h_vertex_counter_sp) * 6 + 3],
			h_vertices_lp[(i-h_vertex_counter_sp) * 6 + 4], h_vertices_lp[(i-h_vertex_counter_sp) * 6 + 5],
			true
			);
		
			if (h_vertices_lp[(i-h_vertex_counter_sp) * 6 + 5] > max_largo_loop) 
				max_largo_loop=h_vertices_lp[(i-h_vertex_counter_sp) * 6 + 5];
		}	
		
			
		VertexAdapter adapter(vertices_[i]);
		id_map_[adapter.b()] = i;
		id_map_[adapter.rb()] = i;
	}

	assert(vertices_.size() * 2 - h_count_palindrome >= id_map_.size());

	timer.stop();
	xinfo("---GPU---Construccion grafo Unitig---Fin cargar resultados en estructuras CPU para continuar procesamiento, tiempo insumido:{.3}\n", timer.elapsed());
	//xinfo("---GPU---Cant_aristas_entrada:{},Cant_vertices_salida_sp:{},Cant_vertices_salida_loop:{},Cant_palindromos:{},LargoMax_CamSimple:{},Largo_max_loop:{}\n", numEdges, h_vertex_counter_sp,h_vertex_counter_lp,(int)h_count_palindrome, max_largo_sp,max_largo_loop);     
	xinfo("---GPU---Cant_aristas_entrada:{},Cant_vertices_salida_simplePath:{},Cant_vertices_salida_loops:{},Cant_palindromos:{},LargoMax_CamSimple:{},Largo_max_loop:{}\n", numEdges, h_vertex_counter_sp, h_vertex_counter_lp,(int)h_count_palindrome, max_largo_sp,max_largo_loop);     

}








void UnitigGraph::RefreshDisconnected() {
  SpinLock mutex;
#pragma omp parallel for
  for (size_type i = 0; i < vertices_.size(); ++i) {
    auto adapter = MakeSudoAdapter(i);
    if (adapter.IsToDelete() || adapter.IsPalindrome() || adapter.IsLoop()) {
      continue;
    }

    uint8_t to_disconnect = adapter.IsToDisconnect();
    adapter.ReverseComplement();
    uint8_t rc_to_disconnect = adapter.IsToDisconnect();
    adapter.ReverseComplement();

    if (!to_disconnect && !rc_to_disconnect) {
      continue;
    }

    if (adapter.GetLength() <= to_disconnect + rc_to_disconnect) {
      adapter.SetToDelete();
      continue;
    }

    auto old_start = adapter.b();
    auto old_end = adapter.e();
    auto old_rc_start = adapter.rb();
    auto old_rc_end = adapter.re();
    uint64_t new_start, new_end, new_rc_start, new_rc_end;

    if (to_disconnect) {
      new_start = sdbg_->NextSimplePathEdge(old_start);
      new_rc_end = sdbg_->PrevSimplePathEdge(old_rc_end);
      assert(new_start != SDBG::kNullID && new_rc_end != SDBG::kNullID);
      sdbg_->SetInvalidEdge(old_start);
      sdbg_->SetInvalidEdge(old_rc_end);
    } else {
      new_start = old_start;
      new_rc_end = old_rc_end;
    }

    if (rc_to_disconnect) {
      new_rc_start = sdbg_->NextSimplePathEdge(old_rc_start);
      new_end = sdbg_->PrevSimplePathEdge(old_end);
      assert(new_rc_start != SDBG::kNullID && new_end != SDBG::kNullID);
      sdbg_->SetInvalidEdge(old_rc_start);
      sdbg_->SetInvalidEdge(old_end);
    } else {
      new_rc_start = old_rc_start;
      new_end = old_end;
    }

    uint32_t new_length =
        adapter.GetLength() - to_disconnect - rc_to_disconnect;
    uint64_t new_total_depth = lround(adapter.GetAvgDepth() * new_length);
    adapter.SetBeginEnd(new_start, new_end, new_rc_start, new_rc_end);
    adapter.SetLength(new_length);
    adapter.SetTotalDepth(new_total_depth);

    std::lock_guard<SpinLock> lk(mutex);
    if (to_disconnect) {
      id_map_.erase(old_start);
      id_map_[new_start] = i;
    }
    if (rc_to_disconnect) {
      id_map_.erase(old_rc_start);
      id_map_[new_rc_start] = i;
    }
  }
}

void UnitigGraph::Refresh(bool set_changed) {
  static const uint8_t kDeleted = 0x1;
  static const uint8_t kVisited = 0x2;
  RefreshDisconnected();
#pragma omp parallel for
  for (size_type i = 0; i < vertices_.size(); ++i) {
    auto adapter = MakeSudoAdapter(i);
    if (!adapter.IsToDelete()) {
      continue;
    }
    adapter.SetFlag(kDeleted);
    if (adapter.IsStandalone()) {
      continue;
    }
    for (int strand = 0; strand < 2; ++strand, adapter.ReverseComplement()) {
      uint64_t cur_edge = adapter.e();
      for (size_t j = 1; j < adapter.GetLength(); ++j) {
        auto prev = sdbg_->UniquePrevEdge(cur_edge);
        sdbg_->SetInvalidEdge(cur_edge);
        cur_edge = prev;
        assert(cur_edge != SDBG::kNullID);
      }
      assert(cur_edge == adapter.b());
      sdbg_->SetInvalidEdge(cur_edge);
      if (adapter.IsPalindrome()) {
        break;
      }
    }
  }

  AtomicBitVector locks(size());
#pragma omp parallel for
  for (size_type i = 0; i < vertices_.size(); ++i) {
    auto adapter = MakeSudoAdapter(i);
    if (adapter.IsStandalone() || (adapter.GetFlag() & kDeleted)) {
      continue;
    }
    for (int strand = 0; strand < 2; ++strand, adapter.ReverseComplement()) {
      if (PrevSimplePathAdapter(adapter).IsValid()) {
        continue;
      }
      if (!locks.try_lock(i)) {
        break;
      }
      std::vector<SudoVertexAdapter> linear_path;
      for (auto cur = NextSimplePathAdapter(adapter); cur.IsValid();
           cur = NextSimplePathAdapter(cur)) {
        linear_path.emplace_back(cur);
      }

      if (linear_path.empty()) {
        adapter.SetFlag(kVisited);
        break;
      }

      size_type back_id = linear_path.back().UnitigId();
      if (back_id != i && !locks.try_lock(back_id)) {
        if (back_id > i) {
          locks.unlock(i);
          break;
        } else {
          locks.lock(back_id);
        }
      }

      auto new_length = adapter.GetLength();
      auto new_total_depth = adapter.GetTotalDepth();
      adapter.SetFlag(kVisited);

      for (auto &v : linear_path) {
        new_length += v.GetLength();
        new_total_depth += v.GetTotalDepth();
        if (v.canonical_id() != adapter.canonical_id()) v.SetFlag(kDeleted);
      }

      auto new_start = adapter.b();
      auto new_rc_end = adapter.re();
      auto new_rc_start = linear_path.back().rb();
      auto new_end = linear_path.back().e();

      adapter.SetBeginEnd(new_start, new_end, new_rc_start, new_rc_end);
      adapter.SetLength(new_length);
      adapter.SetTotalDepth(new_total_depth);
      if (set_changed) adapter.SetChanged();
      break;
    }
  }

  // looped path
  std::mutex mutex;
#pragma omp parallel for
  for (size_type i = 0; i < vertices_.size(); ++i) {
    auto adapter = MakeSudoAdapter(i);
    if (!adapter.IsStandalone() && !adapter.GetFlag()) {
      std::lock_guard<std::mutex> lk(mutex);
      if (adapter.GetFlag()) {
        continue;
      }

      uint32_t length = adapter.GetLength();
      uint64_t total_depth = adapter.GetTotalDepth();
      SudoVertexAdapter next_adapter = adapter;
      while (true) {
        next_adapter = NextSimplePathAdapter(next_adapter);
        assert(next_adapter.IsValid());
        if (next_adapter.b() == adapter.b()) {
          break;
        }
        next_adapter.SetFlag(kDeleted);
        length += next_adapter.GetLength();
        total_depth += next_adapter.GetTotalDepth();
      }

      auto new_start = adapter.b();
      auto new_end = sdbg_->PrevSimplePathEdge(new_start);
      auto new_rc_end = adapter.re();
      auto new_rc_start = sdbg_->NextSimplePathEdge(new_rc_end);
      assert(new_start == sdbg_->EdgeReverseComplement(new_rc_end));
      assert(new_end == sdbg_->EdgeReverseComplement(new_rc_start));

      adapter.SetBeginEnd(new_start, new_end, new_rc_start, new_rc_end);
      adapter.SetLength(length);
      adapter.SetTotalDepth(total_depth);
      adapter.SetLooped();
      if (set_changed) adapter.SetChanged();
    }
  }

  vertices_.resize(std::remove_if(vertices_.begin(), vertices_.end(),
                                  [](UnitigGraphVertex &a) {
                                    return SudoVertexAdapter(a).GetFlag() &
                                           kDeleted;
                                  }) -
                   vertices_.begin());

  size_type num_changed = 0;
#pragma omp parallel for reduction(+ : num_changed)
  for (size_type i = 0; i < vertices_.size(); ++i) {
    auto adapter = MakeSudoAdapter(i);
    assert(adapter.IsStandalone() || adapter.GetFlag());
    adapter.SetFlag(0);
    id_map_.at(adapter.b()) = i;
    id_map_.at(adapter.rb()) = i;
    num_changed += adapter.IsChanged();
  }
}

std::string UnitigGraph::VertexToDNAString(VertexAdapter v) {
  v.ToUniqueFormat();
  std::string label;
  label.reserve(k() + v.GetLength());
  uint64_t cur_edge = v.e();

  for (unsigned i = 1; i < v.GetLength(); ++i) {
    int8_t cur_char = sdbg_->GetW(cur_edge);
    label.push_back("ACGT"[cur_char > 4 ? (cur_char - 5) : (cur_char - 1)]);

    cur_edge = sdbg_->PrevSimplePathEdge(cur_edge);
    if (cur_edge == SDBG::kNullID) {
      xfatal("{}, {}, {}, {}, ({}, {}), {}, {}\n", v.b(), v.e(), v.rb(), v.re(),
             sdbg_->EdgeReverseComplement(v.e()),
             sdbg_->EdgeReverseComplement(v.b()), v.GetLength(), i);
    }
  }

  int8_t cur_char = sdbg_->GetW(cur_edge);
  label.push_back("ACGT"[cur_char > 4 ? (cur_char - 5) : (cur_char - 1)]);

  if (cur_edge != v.b()) {
    xfatal("fwd: {}, {}, rev: {}, {}, ({}, {}) length: {}\n", v.b(), v.e(),
           v.rb(), v.re(), sdbg_->EdgeReverseComplement(v.e()),
           sdbg_->EdgeReverseComplement(v.b()), v.GetLength());
  }

  uint8_t seq[kMaxK];
  sdbg_->GetLabel(v.b(), seq);

  for (int i = sdbg_->k() - 1; i >= 0; --i) {
    assert(seq[i] >= 1 && seq[i] <= 4);
    label.append(1, "ACGT"[seq[i] - 1]);
  }

  std::reverse(label.begin(), label.end());
  return label;
}




