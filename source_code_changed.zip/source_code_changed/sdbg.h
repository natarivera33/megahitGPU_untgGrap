//
// Created by vout on 11/5/18.
//

#ifndef MEGAHIT_SDBG_H
#define MEGAHIT_SDBG_H

#include "sdbg_def.h"
#include "sdbg_raw_content.h"

#include <cassert>
#include <iostream>
#include <vector>
#include "kmlib/kmbitvector.h"
#include "kmlib/kmrns.h"

#ifdef USE_GPU
  #include <cuda_runtime.h>   // cudaMalloc/cudaMemcpy/cudaFree/cudaMemset
#endif
#include "utils/utils.h"

#define CUDA_CHECK(call)                                                   \
do {                                                                       \
    cudaError_t err = (call);                                              \
    if (err != cudaSuccess) {                                              \
        fprintf(stderr, "CUDA error %s:%d: %s\n",                          \
                __FILE__, __LINE__, cudaGetErrorString(err));              \
        exit(EXIT_FAILURE);                                                \
    }                                                                      \
} while (0)




//static constexpr uint64_t kNullID = static_cast<uint64_t>(-1);

/**
 * Succicent De Bruijn graph
 */
class SDBG {
 public:
  static constexpr uint64_t kNullID = static_cast<uint64_t>(-1);
  static constexpr uint32_t kNullID32 = static_cast<uint32_t>(-1);//agrego

 
  SDBG() = default;
  ~SDBG() = default;
  
  void LoadFromFile(const char *dbg_name) {
  
 //  SimpleTimer timer;
//   timer.reset();
//   timer.start();
  
    LoadSdbgRawContent(&content_, dbg_name);
    k_ = content_.meta.k();
    rs_is_tip_.from_packed_array(content_.tip.data(),
                                 content_.meta.item_count());
    rs_w_.from_packed_array(content_.w.data(), content_.meta.item_count());
    rs_last_.from_packed_array(content_.last.data(),
                               content_.meta.item_count());
    invalid_ = kmlib::AtomicBitVector<uint64_t>(
        content_.tip.data(), content_.tip.data() + content_.tip.word_count());
    prefix_look_up_.resize(content_.meta.bucket_count());
    std::fill(f_, f_ + kAlphabetSize + 2, 0);
    f_[0] = -1;
    for (auto it = content_.meta.begin_bucket();
         it != content_.meta.end_bucket() && it->bucket_id != it->kNullID;
         ++it) {
      f_[it->bucket_id / (content_.meta.bucket_count() / kAlphabetSize) + 2] +=
          it->num_items;
      prefix_look_up_[it->bucket_id].first = it->accumulate_item_count;
      prefix_look_up_[it->bucket_id].second =
          it->accumulate_item_count + it->num_items - 1;
    }
    for (unsigned i = 2; i < kAlphabetSize + 2; ++i) {
      f_[i] += f_[i - 1];
    }

    for (unsigned i = 1; i < kAlphabetSize + 2; ++i) {
      rank_f_[i] = rs_last_.rank(f_[i] - 1);
    }

 // timer.stop();
 // xinfoc("---CPU---Cargar Grafo Bruijn desde archivo---Tiempo previo a FOR que se modifica en codigo GPU:{.3}\n", timer.elapsed());
  
  /* timer.reset();
   timer.start();*/
   
    uint64_t numEdges= content_.meta.item_count();
   
   #pragma omp parallel for schedule(static)
    for (uint64_t i = 0; i < numEdges; ++i) {
      if (GetW(i) == 0) {
        SetInvalidEdge(i);
      }
    }
    
    
       
  	host_edge_multiplicity.assign(numEdges, 0);


 /* timer.stop();
  xinfoc("---CPU---Cargar Grafo Bruijn desde archivo---Tiempo FOR que se modifica para GPU:{.3}\n", timer.elapsed());*/

  }


  uint64_t size() const { return content_.meta.item_count(); }

  uint32_t k() const { return k_; }

  uint8_t GetW(uint64_t x) const { return content_.w[x]; }

  bool IsLast(uint64_t x) const { return content_.last[x]; }

  bool IsLastOrTip(uint64_t x) const {
    return ((content_.last.data()[x / 64] | content_.tip.data()[x / 64]) >>
            (x % 64)) &
           1u;
  }

  int64_t GetLastIndex(uint64_t x) const { return rs_last_.succ(x); }

  uint8_t LastCharOf(uint64_t x) const {
    for (uint8_t i = 1; i < kAlphabetSize + 2; ++i) {
      if (f_[i] > int64_t(x)) {
        return i - 1;
      }
    }
    return kAlphabetSize + 2;
  }

  bool IsValidEdge(uint64_t edge_id) const {    return (!invalid_.at(edge_id));  }

  bool IsTip(uint64_t edge_id) const { return content_.tip[edge_id]; }

  void SetValidEdge(uint64_t edge_id) { 
        invalid_.unset(edge_id);
        /*host_is_valid_edge[edge_id]=1;
        
    	//////////para probar a ver que pasa si los calculo acá... No funciono, esta función no se está llamando de ningún
	const uint64_t numEdges = size();

	uint64_t next = NextSimplePathEdge(edge_id);	  	
      	if (next >= numEdges) next = kNullID;
      	host_next_edge[edge_id] = next;

  	uint64_t prev = PrevSimplePathEdge(edge_id);
	if (prev >= numEdges) prev = kNullID;	
	host_prev_edge[edge_id] = prev;
	
    	int64_t mult  = EdgeMultiplicity(edge_id);
  	host_edge_multiplicity[edge_id] = mult;
  	
	uint64_t rc = EdgeReverseComplement(edge_id); 
	host_rc_edge[edge_id] = rc;*/
	//fin prueba
        
   }

  void SetInvalidEdge(uint64_t edge_id) { 
    invalid_.set(edge_id);
  
 /*   host_is_valid_edge[edge_id]=0;
    host_next_edge[edge_id] = kNullID;
    host_prev_edge[edge_id] = kNullID;
    host_rc_edge[edge_id]   = kNullID;
    host_edge_multiplicity[edge_id] = 0;*/
     }

 /* mul_t EdgeMultiplicity(uint64_t edge_id) const {
    if (!content_.full_mul.empty()) {
      return content_.full_mul[edge_id];
    }
    if (content_.small_mul[edge_id] != kSmallMulSentinel) {
      return content_.small_mul[edge_id];
    } else {
      return content_.large_mul.at(edge_id);
    }
  }*///original

  mul_t EdgeMultiplicity(uint64_t edge_id)  {
   if (host_edge_multiplicity[edge_id] != 0)
   	return host_edge_multiplicity[edge_id]; 
    mul_t mul;
    if (!content_.full_mul.empty()) {
      mul = content_.full_mul[edge_id];
      //xinfoc("---GPU---Tome de full_mul\n");
    }
    else if (content_.small_mul[edge_id] != kSmallMulSentinel) {
      mul = content_.small_mul[edge_id];
      //xinfoc("---GPU---Tome de small_mul\n");
    } else {
      mul= content_.large_mul.at(edge_id);
     // xinfoc("---GPU---Tome de large_mul\n");
    }
    uint16_t multA =mul;  
    host_edge_multiplicity[edge_id] = multA;
    return mul;
  }




  uint64_t Forward(uint64_t edge_id) const {  // the last edge edge_id points to
    uint8_t a = GetW(edge_id);
    if (a > kAlphabetSize) {
      a -= kAlphabetSize;
    }
    int64_t count_a = rs_w_.rank(a, edge_id);
    return rs_last_.select(rank_f_[a] + count_a - 1);
  }

  uint64_t Backward(
      uint64_t edge_id) const {  // the first edge points to edge_id
    uint8_t a = LastCharOf(edge_id);
    int64_t count_a = rs_last_.rank(edge_id - 1) - rank_f_[a];
    return rs_w_.select(a, count_a);
  }

 private:
  const label_word_t *TipLabelStartPtr(uint64_t edge_id) const {
    return content_.tip_lables.data() +
           content_.meta.words_per_tip_label() * (rs_is_tip_.rank(edge_id) - 1);
  }
  static uint8_t CharAtTipLabel(const label_word_t *label_start_ptr,
                                unsigned offset) {
    return kmlib::CompactVector<kBitsPerChar, label_word_t>::at(label_start_ptr,
                                                                offset) +
           1;
  }

 public:
  /**
   * Find the index given a sequence
   * @param seq the sequence encoded in [0-3]
   * @return the index of the sequence in the graph, kNullID if not exists
   */
   
	// Arreglos auxiliares precalculados
//	std::vector<uint8_t> host_is_valid_edge;
        std::vector<uint64_t> host_is_valid_edge_bits;
	std::vector<uint32_t> host_next_edge;
	std::vector<uint32_t> host_prev_edge;
	std::vector<uint32_t> host_rc_edge;
	std::vector<uint16_t> host_edge_multiplicity;
 	/*std::vector<uint64_t> host_uniqueNextEdge;
    	std::vector<uint64_t> host_uniquePrevEdge;*///esto fue un intento de cargar esos vectores en trim


	//uint8_t *d_isValidEdge;
	uint64_t *d_isValidEdgeBits, *d_locks;
	uint32_t *d_prevEdge, *d_rcEdge;
	uint32_t *d_nextEdge;
	uint16_t *d_edgeMultiplicity;
	int *d_count_palindrome;
	uint32_t *d_vertices;
	unsigned int *d_vertex_counter;
	

	   
	const uint32_t* GetHostNextEdge() const { return host_next_edge.data(); }
	const uint32_t* GetHostPrevEdge() const { return host_prev_edge.data(); }
	const uint32_t* GetHostRcEdge()   const { return host_rc_edge.data(); }
	const uint16_t*  GetHostMultiplicity() const { return host_edge_multiplicity.data(); }
	//const uint8_t* GetHostValidEdge() const { return host_is_valid_edge.data(); }

	bool GetHostIsValidEdge(uint32_t i) {
	    return (host_is_valid_edge_bits[i >> 6] >> (i & 63)) & 1ULL;
	}

	void SetHostIsValidEdge(uint32_t i) {
	    host_is_valid_edge_bits[i >> 6] |= (1ULL << (i & 63));
	}

	void ClearHostIsValidEdge(uint32_t i) {
	    host_is_valid_edge_bits[i >> 6] &= ~(1ULL << (i & 63));
	}



  	void prepararEjecucionGPU_hallarCamSimples_Loops();
	void reservarMemoriaGPU(uint32_t numEdges);
	void reservarMemoriaGPU_async(uint32_t numEdges);
	void copiarDatosGPU(uint32_t numEdges);
	void copiarDatosGPU_async(uint32_t numEdges);	
	
  uint64_t IndexBinarySearch(const uint8_t *seq) const {
    uint64_t prefix = 0;
    for (uint64_t i = 0; (1u << (i * kBitsPerChar)) < prefix_look_up_.size();
         ++i) {
      prefix = prefix * kAlphabetSize + seq[k_ - 1 - i] - 1;
    }
    auto l = prefix_look_up_[prefix].first;
    auto r = prefix_look_up_[prefix].second;

    while (l <= r) {
      int cmp = 0;
      uint64_t mid = (l + r) / 2;
      uint64_t y = mid;

      for (int i = k_ - 1; i >= 0; --i) {
        if (IsTip(y)) {
          const label_word_t *tip_label = TipLabelStartPtr(y);
          for (int j = 0; j < i; ++j) {
            auto c = CharAtTipLabel(tip_label, j);
            if (c < seq[i - j]) {
              cmp = -1;
              break;
            } else if (c > seq[i - j]) {
              cmp = 1;
              break;
            }
          }

          if (cmp == 0) {
            if (IsTip(mid)) {
              cmp = -1;
            } else {
              auto c = CharAtTipLabel(tip_label, i);
              if (c < seq[0]) {
                cmp = -1;
                break;
              } else if (c > seq[0]) {
                cmp = 1;
                break;
              }
            }
          }
          break;
        }

        y = Backward(y);
        uint8_t c = GetW(y);

        if (c < seq[i]) {
          cmp = -1;
          break;
        } else if (c > seq[i]) {
          cmp = 1;
          break;
        }
      }

      if (cmp == 0) {
        return GetLastIndex(mid);
      } else if (cmp > 0) {
        r = mid - 1;
      } else {
        l = mid + 1;
      }
    }
    return kNullID;
  }
  /**
   * Fetch the label of an edge from the graph
   * @param id the index in the graph
   * @param seq the label will be written to this address
   * @return the length of label (always k)
   */
  uint32_t GetLabel(uint64_t id, uint8_t *seq) const {
    uint64_t x = id;
    for (int i = k_ - 1; i >= 0; --i) {
      if (IsTip(x)) {
        const label_word_t *tip_label = TipLabelStartPtr(x);
        for (int j = 0; j <= i; ++j) {
          seq[i - j] = CharAtTipLabel(tip_label, j);
        }
        break;
      }
      x = Backward(x);
      seq[i] = GetW(x);
      if (seq[i] > kAlphabetSize) {
        seq[i] -= kAlphabetSize;
      }
    }
    return k_;
  }

 private:
  static const uint8_t kFlagWriteOut = 0x1;
  static const uint8_t kFlagMustEq0 = 0x2;
  static const uint8_t kFlagMustEq1 = 0x4;
  /**
   * An internal function to collect incoming edges & in-degrees
   * @tparam flag
   * @param edge_id
   * @param incomings the incoming edges will be written in the address if
   * kFlagWriteOut is set
   * @return in degree of the edge; -1 if edge or flag invalid
   */
  template <uint8_t flag = 0>
  int ComputeIncomings(uint64_t edge_id, uint64_t *incomings) const {
    if (!IsValidEdge(edge_id)) {
      return -1;
    }
    uint64_t first_income = Backward(edge_id);
    uint8_t c = GetW(first_income);
    unsigned count_ones = IsLastOrTip(first_income);
    int indegree = IsValidEdge(first_income);

    if (flag & kFlagMustEq0) {
      if (indegree) return -1;
    }

    if (flag & kFlagWriteOut) {
      if (indegree > 0) {
        incomings[0] = first_income;
      }
    }

    for (uint64_t y = first_income + 1;
         count_ones < kAlphabetSize + 1 && y < size(); ++y) {
      count_ones += IsLastOrTip(y);
      uint8_t cur_char = GetW(y);

      if (cur_char == c) {
        break;
      } else if (cur_char == c + kAlphabetSize && IsValidEdge(y)) {
        if (flag & kFlagMustEq0) {
          return -1;
        } else if (flag & kFlagMustEq1) {
          if (indegree == 1) return -1;
        }
        if (flag & kFlagWriteOut) {
          assert(incomings != nullptr);
          incomings[indegree] = y;
        }
        ++indegree;
      }
    }
    return indegree;
  }
  
  
  template <uint8_t flag = 0>
  int ComputeIncomings_paraGPU(uint64_t edge_id, uint64_t *incomings) const {
    if (GetW(edge_id) == 0) {
      return -1;
    }
    uint64_t first_income = Backward(edge_id);
    uint8_t c = GetW(first_income);
    unsigned count_ones = IsLastOrTip(first_income);
    int indegree = (GetW(first_income)!=0);//IsValidEdge(first_income);

    if (flag & kFlagMustEq0) {
      if (indegree) return -1;
    }

    if (flag & kFlagWriteOut) {
      if (indegree > 0) {
        incomings[0] = first_income;
      }
    }

    for (uint64_t y = first_income + 1;
         count_ones < kAlphabetSize + 1 && y < size(); ++y) {
      count_ones += IsLastOrTip(y);
      uint8_t cur_char = GetW(y);

      if (cur_char == c) {
        break;
      } else if (cur_char == c + kAlphabetSize && (GetW(y)!=0)) {
        if (flag & kFlagMustEq0) {
          return -1;
        } else if (flag & kFlagMustEq1) {
          if (indegree == 1) return -1;
        }
        if (flag & kFlagWriteOut) {
          assert(incomings != nullptr);
          incomings[indegree] = y;
        }
        ++indegree;
      }
    }
    return indegree;
  }
  
  /**
   * An internal function to collect outgoing edges & in-degrees
   * @tparam flag
   * @param edge_id
   * @param outgoings the outgoing edges will be written in the address if
   * kFlagWriteOut is set
   * @return out degree of the edge; -1 if edge or flag invalid
   */
  template <uint8_t flag = 0>
  int ComputeOutgoings(uint64_t edge_id, uint64_t *outgoings) const {
    if (!IsValidEdge(edge_id)) {
      return -1;
    }
    uint64_t outdegree = 0;
    uint64_t next_edge = Forward(edge_id);
    do {
      if (IsValidEdge(next_edge)) {
        if (flag & kFlagMustEq0) {
          return -1;
        } else if (flag & kFlagMustEq1) {
          if (outdegree == 1) return -1;
        }
        if (flag & kFlagWriteOut) {
          assert(outgoings != nullptr);
          outgoings[outdegree] = next_edge;
        }
        ++outdegree;
      }
      --next_edge;
    } while (next_edge != kNullID && !IsLastOrTip(next_edge));

    return outdegree;
  }

  template <uint8_t flag = 0>
  int ComputeOutgoings_paraGPU(uint64_t edge_id, uint64_t *outgoings) const {
    if (GetW(edge_id) == 0) {
      return -1;
    }
    uint64_t outdegree = 0;
    uint64_t next_edge = Forward(edge_id);
    do {
      if (GetW(next_edge) != 0) {
        if (flag & kFlagMustEq0) {
          return -1;
        } else if (flag & kFlagMustEq1) {
          if (outdegree == 1) return -1;
        }
        if (flag & kFlagWriteOut) {
          assert(outgoings != nullptr);
          outgoings[outdegree] = next_edge;
        }
        ++outdegree;
      }
      --next_edge;
    } while (next_edge != kNullID && !IsLastOrTip(next_edge));

    return outdegree;
  }

 public:
  /**
   * the in-degree of a node/edge
   * @param edge_id
   * @return the in-degree. -1 if id invalid.
   */
  int EdgeIndegree(uint64_t edge_id) const {
    return ComputeIncomings(edge_id, nullptr);
  }
  /**
   * the out-degree of an edge
   * @param edge_id
   * @return the out-degree. -1 if id invalid
   */
  int EdgeOutdegree(uint64_t edge_id) const {
    return ComputeOutgoings(edge_id, nullptr);
  }
  /**
   * get all incoming edges of an edge
   * @param edge_id
   * @param incomings all incoming edges' id will be written here
   * @return in-degree
   */
  int IncomingEdges(uint64_t edge_id, uint64_t *incomings) const {
    return ComputeIncomings<kFlagWriteOut>(edge_id, incomings);
  }
  /**
   * get all outgoing edges of an edge
   * @param edge_id
   * @param outgoings all outgoing edges' id will be written here
   * @return out-degree
   */
  int OutgoingEdges(uint64_t edge_id, uint64_t *outgoings) const {
    return ComputeOutgoings<kFlagWriteOut>(edge_id, outgoings);
  }
  /**
   * a more efficient way to judge whether an edge's in-degree is 0
   * @param edge_id
   * @return true if the edge's in-degree is 0
   */
  bool EdgeIndegreeZero(uint64_t edge_id) const {
    return ComputeIncomings<kFlagMustEq0>(edge_id, nullptr) == 0;
  }
  /**
   * A more efficient way to judge whether an edge's out-degree is 0
   * @param edge_id
   * @return true if the edge's out-degree is 0
   */
  bool EdgeOutdegreeZero(uint64_t edge_id) const {
    return ComputeOutgoings<kFlagMustEq0>(edge_id, nullptr) == 0;
  }
  /**
   * @param edge_id
   * @return if the edge has only one outgoing edge, return that one; otherwise
   * -1
   */
  uint64_t UniqueNextEdge(uint64_t edge_id) const {
    uint64_t ret = 0;
    if (ComputeOutgoings<kFlagWriteOut | kFlagMustEq1>(edge_id, &ret) == 1) {
          //assert(edge_id < host_uniqueNextEdge.size());
	//host_uniqueNextEdge[edge_id]=ret;
      return ret;
    } else {
      return kNullID;
    }
  }
  
  
 /* uint64_t UniqueNextEdge_paraGPU(uint64_t edge_id) const {
	    uint64_t ret = 0;
	    if (ComputeOutgoings_paraGPU<kFlagWriteOut | kFlagMustEq1>(edge_id, &ret) == 1) {
      return ret;
    } else {
      return kNullID;
    }
  }*/
  /**
   * @param edge_id
   * @return if the edge has only one incoming edge, return that one; otherwise
   * -1
   */
  uint64_t UniquePrevEdge(uint64_t edge_id) const {
    uint64_t ret = 0;
    if (ComputeIncomings<kFlagWriteOut | kFlagMustEq1>(edge_id, &ret) == 1) {
    //    assert(edge_id < host_uniquePrevEdge.size());
    //	host_uniquePrevEdge[edge_id]=ret;
      return ret;
    } else {
      return kNullID;
    }
  }
  
  /*  uint64_t UniquePrevEdge_paraGPU(uint64_t edge_id) const {
    uint64_t ret = 0;
    if (ComputeIncomings<kFlagWriteOut | kFlagMustEq1>(edge_id, &ret) == 1) {//deberia ser ComputeIncomings_paraGPU pero no funciona bien si la cambio
      return ret;
    } else {
      return kNullID;
    }
  }*/
  
  
  
  
  /**
   * @param edge_id
   * @return if the edge has only one incoming edge which is on a simple path,
   * return that one;
   * otherwise -1
   */
  uint64_t PrevSimplePathEdge(uint64_t edge_id) const {
    uint64_t prev_edge = UniquePrevEdge(edge_id);
    if (prev_edge != kNullID && UniqueNextEdge(prev_edge) != kNullID) {
      //host_prev_edge[edge_id] = static_cast<uint32_t>(prev_edge);//agrego para probar
      return prev_edge;
    } else {
      return kNullID;
    }
  }
  
  
    uint32_t PrevSimplePathEdge32(uint64_t edge_id) const {
    uint64_t prev_edge = UniquePrevEdge(edge_id);
//	  assert(edge_id < host_uniquePrevtEdge.size());
  //    uint64_t prev_edge = host_uniquePrevEdge[edge_id]; 
    if (prev_edge != kNullID && UniqueNextEdge(prev_edge) != kNullID) {
      return static_cast<uint32_t>(prev_edge);
    } else {
      return kNullID32;
    }
  }
  
 /*  uint64_t PrevSimplePathEdge_paraGPU(uint64_t edge_id) const {
   // printf("1\n");
    uint64_t prev_edge = UniquePrevEdge_paraGPU(edge_id);
   //     printf("2\n");
    if (prev_edge != kNullID && UniqueNextEdge_paraGPU(prev_edge) != kNullID) {
      //assert(prev_edge < size());
      //    printf("3\n");
      return prev_edge;
    } else {
      return kNullID;
    }
  }*/
  
  /**
   * @param edge_id
   * @return if the edge has only one outgoing edge which is on a simple path,
   * return that one;
   * otherwise -1
   */
  uint64_t NextSimplePathEdge(uint64_t edge_id) const {
    uint64_t next_edge = UniqueNextEdge(edge_id);
    if (next_edge != kNullID && UniquePrevEdge(next_edge) != kNullID) {
      assert(next_edge < size());
      return next_edge;
    } else {
      return kNullID;
    }
  }
  

uint32_t NextSimplePathEdge32(uint64_t edge_id) const {

    uint64_t next_edge = UniqueNextEdge(edge_id);
    //uint64_t next_edge = host_uniqueNextEdge[edge_id];
    if (next_edge != kNullID && UniquePrevEdge(next_edge) != kNullID) {
        assert(next_edge < size());
        assert(next_edge <= UINT32_MAX);
        return static_cast<uint32_t>(next_edge);
    } else {
        return kNullID32;
    }
}
  
  
  
  /*  uint32_t NextSimplePathEdge(uint32_t edge_id) const {
    uint32_t next_edge = UniqueNextEdge(edge_id);
    if (next_edge != kNullID && UniquePrevEdge(next_edge) != kNullID) {
      assert(next_edge < size());
      return next_edge;
    } else {
      return kNullID;
    }
  }*/
  
 /* uint64_t NextSimplePathEdge_paraGPU(uint64_t edge_id) const {
    uint64_t next_edge = UniqueNextEdge_paraGPU(edge_id);
    if (next_edge != kNullID && UniquePrevEdge_paraGPU(next_edge) != kNullID) {
      assert(next_edge < size());
      return next_edge;
    } else {
      return kNullID;
    }
  }*/
  /**
   * @param edge_id
   * @return the index of the reverse-complement edge of the input edge
   */
  uint64_t EdgeReverseComplement(uint64_t edge_id) const {
    if (!IsValidEdge(edge_id)) {
      //host_rc_edge[edge_id] = kNullID;
      return kNullID;
    }

    uint8_t seq[kMaxK + 1];
    GetLabel(edge_id, seq);
    seq[k_] = GetW(edge_id);

    if (seq[k_] > kAlphabetSize) {
      seq[k_] -= kAlphabetSize;
    }

    for (int i = 0, j = k_; i < j; ++i, --j) {
      std::swap(seq[i], seq[j]);
    }
    for (unsigned i = 0; i < k_ + 1; ++i) {
      seq[i] = kAlphabetSize + 1 - seq[i];
    }

    uint64_t rev_node = IndexBinarySearch(seq);
    if (rev_node == kNullID) { /*host_rc_edge[edge_id] = kNullID;*/ return kNullID;}
    do {
      uint8_t edge_label = GetW(rev_node);
      if (edge_label == seq[k_] || edge_label - kAlphabetSize == seq[k_]) {
        assert(rev_node < size());
        /*host_rc_edge[edge_id] = rev_node;*/
        return rev_node;
      }
      --rev_node;
    } while (rev_node != kNullID && !IsLastOrTip(rev_node));

    /*host_rc_edge[edge_id] = kNullID;*/
    return kNullID;
  }


  uint32_t EdgeReverseComplement32(uint64_t edge_id) const {
    if (!IsValidEdge(edge_id)) {
      return kNullID32;
    }

    uint8_t seq[kMaxK + 1];
    GetLabel(edge_id, seq);
    seq[k_] = GetW(edge_id);

    if (seq[k_] > kAlphabetSize) {
      seq[k_] -= kAlphabetSize;
    }

    for (int i = 0, j = k_; i < j; ++i, --j) {
      std::swap(seq[i], seq[j]);
    }
    for (unsigned i = 0; i < k_ + 1; ++i) {
      seq[i] = kAlphabetSize + 1 - seq[i];
    }

    uint64_t rev_node = IndexBinarySearch(seq);
    if (rev_node == kNullID) { /*host_rc_edge[edge_id] = kNullID;*/ return kNullID;}
    do {
      uint8_t edge_label = GetW(rev_node);
      if (edge_label == seq[k_] || edge_label - kAlphabetSize == seq[k_]) {
        assert(rev_node < size());
        return static_cast<uint32_t>(rev_node);
      }
      --rev_node;
    } while (rev_node != kNullID && !IsLastOrTip(rev_node));

    return kNullID32;
  }






	
/* uint64_t EdgeReverseComplement_paraGPU(uint64_t edge_id) const {
    if (GetW(edge_id) == 0) {
      return kNullID;
    }

    uint8_t seq[kMaxK + 1];
    GetLabel(edge_id, seq);
    seq[k_] = GetW(edge_id);

    if (seq[k_] > kAlphabetSize) {
      seq[k_] -= kAlphabetSize;
    }

    for (int i = 0, j = k_; i < j; ++i, --j) {
      std::swap(seq[i], seq[j]);
    }
    for (unsigned i = 0; i < k_ + 1; ++i) {
      seq[i] = kAlphabetSize + 1 - seq[i];
    }

    uint64_t rev_node = IndexBinarySearch(seq);
    if (rev_node == kNullID) return kNullID;
    do {
      uint8_t edge_label = GetW(rev_node);
      if (edge_label == seq[k_] || edge_label - kAlphabetSize == seq[k_]) {
        assert(rev_node < size());
        return rev_node;
      }
      --rev_node;
    } while (rev_node != kNullID && !IsLastOrTip(rev_node));

    return kNullID;
  }*/


  /**
   * free multiplicity of all edges to reduce memory
   * WARNING: use this with cautions
   * After that EdgeMultiplicity() is invalid
   */
  void FreeMultiplicity() {
    content_.large_mul = phmap::parallel_flat_hash_map<uint64_t, mul_t>();
    content_.small_mul = std::vector<small_mul_t>();
    content_.full_mul = std::vector<mul_t>();
  }

  public: kmlib::AtomicBitVector<uint64_t> invalid_;
  
  

 private:
  uint32_t k_{};
  SdbgRawContent content_;

  std::vector<std::pair<int64_t, int64_t>> prefix_look_up_;
  int64_t f_[kAlphabetSize + 2]{};
  int64_t rank_f_[kAlphabetSize + 2]{};  // = rs_last_.Rank(f_[i] - 1)
  kmlib::RankAndSelect<kAlphabetSize, kWAlphabetSize> rs_w_;
  kmlib::RankAndSelect<1, 2> rs_last_;
  kmlib::RankAndSelect<1, 2, kmlib::rnsmode::kRankOnly> rs_is_tip_;
};

#endif  // MEGAHIT_SDBG_H
