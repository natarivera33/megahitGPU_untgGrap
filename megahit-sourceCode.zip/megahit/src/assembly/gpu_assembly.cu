#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>

#include "gpu_assembly.cuh"

// ----------------- helpers -----------------
static inline int grid_for(uint64_t n, int blockSize) {
    return (int)((n + (uint64_t)blockSize - 1) / (uint64_t)blockSize);
}

__host__ void GPU_checkLastCuda(const char* where) {
    cudaError_t e = cudaGetLastError();
    if (e != cudaSuccess) {
        fprintf(stderr, "[CUDA] %s: %s\n", where, cudaGetErrorString(e));
    }
}

__device__ __forceinline__ uint32_t umax_u32(uint32_t a, uint32_t b) {
    return (a > b) ? a : b;
}


__device__ inline bool IsValidEdgeBit(const uint64_t* bits, uint32_t i) {
    return (bits[i >> 6] >> (i & 63)) & 1ULL;
}

__device__ inline bool IsLockedBit(const uint64_t* lockBits, uint32_t i) {
    return (lockBits[i >> 6] >> (i & 63)) & 1ULL;
}

__device__ inline bool TryLockBit(uint64_t* lockBits, uint32_t i) {
    uint32_t word = i >> 6;
    uint32_t bit  = i & 63;
    uint64_t mask = 1ULL << bit;

    uint64_t old = atomicOr(
        reinterpret_cast<unsigned long long*>(&lockBits[word]),
        static_cast<unsigned long long>(mask)
    );

    return (old & mask) == 0ULL;
}

__device__ inline void UnlockBit(uint64_t* lockBits, uint32_t i) {
    uint32_t word = i >> 6;
    uint32_t bit  = i & 63;
    uint64_t mask = 1ULL << bit;

    atomicAnd(
        reinterpret_cast<unsigned long long*>(&lockBits[word]),
        static_cast<unsigned long long>(~mask)
    );
}

__device__ inline void ForceLockBit(uint64_t* lockBits, uint32_t i) {
    uint32_t word = i >> 6;
    uint32_t bit  = i & 63;
    uint64_t mask = 1ULL << bit;

    atomicOr(
        reinterpret_cast<unsigned long long*>(&lockBits[word]),
        static_cast<unsigned long long>(mask)
    );
}

// ========== KERNEL PARA SIMPLE PATHS - SIN max_path NI locked[] ==========
__global__ void procesarCaminosSimples(
    uint64_t* d_isValidEdgeBits,
    uint32_t* d_nextEdge,
    uint32_t* d_prevEdge,
    uint32_t* d_rcEdge,
    uint16_t* d_edgeMultiplicity,
    uint32_t numEdges,
    int* d_count_palindrome,
    uint64_t* d_locks,
    uint32_t* d_vertices,
    unsigned int* d_vertex_counter) {

    uint64_t edge_idx =
        (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;

    const uint32_t MAX_VERTICES_GPU = numEdges;

    if (edge_idx >= MAX_VERTICES_GPU)
        return;

    // Solo comenzar desde una arista válida que sea extremo del camino
    if (!IsValidEdgeBit(d_isValidEdgeBits, edge_idx) ||
        d_nextEdge[edge_idx] != UINT32_MAX)
        return;

    // ------------------------------------------------------------
    // 1. BLOQUEAR ARISTA INICIAL
    // ------------------------------------------------------------

    if (!TryLockBit(d_locks, edge_idx))
        return;

    uint32_t cur_edge = (uint32_t)edge_idx;
    uint32_t prev_edge;

    uint32_t depth = d_edgeMultiplicity[edge_idx];
    uint32_t length = 1;

    // Cantidad de aristas adicionales bloqueadas durante
    // el recorrido hacia atrás.
    // NO incluye edge_idx.
    uint32_t locked_len = 0;

    bool will_be_added = true;

    // ------------------------------------------------------------
    // 2. RECORRER CAMINO SIMPLE HACIA ATRÁS
    // ------------------------------------------------------------

    while ((prev_edge = d_prevEdge[cur_edge]) != UINT32_MAX) {

        // Primero intentar adquirir el lock.
        if (!TryLockBit(d_locks, prev_edge)) {
            will_be_added = false;
            break;
        }

        // El lock fue adquirido por este hilo.
        cur_edge = prev_edge;
        ++locked_len;

        depth += d_edgeMultiplicity[cur_edge];
        ++length;
    }

    // ------------------------------------------------------------
    // 3. ROLLBACK SI NO PUDIMOS COMPLETAR EL CAMINO
    // ------------------------------------------------------------

    if (!will_be_added) {

        // No tenemos locked[].
        // Volvemos a recorrer desde edge_idx por prevEdge
        // exactamente locked_len posiciones.
        uint32_t rollback_edge = (uint32_t)edge_idx;

        for (uint32_t i = 0; i < locked_len; ++i) {

            rollback_edge = d_prevEdge[rollback_edge];

            if (rollback_edge == UINT32_MAX)
                break;

            UnlockBit(d_locks, rollback_edge);
        }

        // Liberar también la arista inicial.
        UnlockBit(d_locks, edge_idx);

        return;
    }

    // ------------------------------------------------------------
    // 4. OBTENER INICIO DEL REVERSE COMPLEMENT
    // ------------------------------------------------------------

    uint32_t rc_start = d_rcEdge[edge_idx];

    if (rc_start == UINT32_MAX) {

        // Rollback del camino directo.
        uint32_t rollback_edge = (uint32_t)edge_idx;

        for (uint32_t i = 0; i < locked_len; ++i) {

            rollback_edge = d_prevEdge[rollback_edge];

            if (rollback_edge == UINT32_MAX)
                break;

            UnlockBit(d_locks, rollback_edge);
        }

        UnlockBit(d_locks, edge_idx);

        return;
    }

    uint32_t rc_end;
    bool extend_full = true;

    // ------------------------------------------------------------
    // 5. INTENTAR BLOQUEAR EL INICIO DEL REVERSE COMPLEMENT
    // ------------------------------------------------------------

    if (!TryLockBit(d_locks, rc_start)) {

        /*
         * Otro hilo ya posee rc_start.
         *
         * Mantenemos la misma lógica de desempate que tenía
         * el kernel original.
         */

        rc_end = d_rcEdge[cur_edge];

        if (rc_end == UINT32_MAX ||
            umax_u32((uint32_t)edge_idx, cur_edge) <
                umax_u32(rc_start, rc_end)) {

            // Rollback del camino directo.
            uint32_t rollback_edge = (uint32_t)edge_idx;

            for (uint32_t i = 0; i < locked_len; ++i) {

                rollback_edge = d_prevEdge[rollback_edge];

                if (rollback_edge == UINT32_MAX)
                    break;

                UnlockBit(d_locks, rollback_edge);
            }

            UnlockBit(d_locks, edge_idx);

            /*
             * NO desbloquear rc_start:
             * TryLockBit(rc_start) falló, por lo tanto
             * este hilo nunca adquirió ese lock.
             */
            return;
        }

    } else {

        // --------------------------------------------------------
        // 6. RECORRER EL REVERSE COMPLEMENT
        // --------------------------------------------------------

        rc_end = rc_start;

        uint32_t rc_cur = rc_start;

        /*
         * Cantidad de aristas bloqueadas DESPUÉS de rc_start.
         * rc_start se cuenta aparte porque ya fue bloqueado arriba.
         */
        uint32_t rc_locked_len = 0;

        while (true) {

            uint32_t rc_next = d_nextEdge[rc_cur];

            if (rc_next == UINT32_MAX)
                break;

            if (!TryLockBit(d_locks, rc_next)) {
                extend_full = false;
                break;
            }

            // El lock pertenece a este hilo.
            rc_cur = rc_next;
            rc_end = rc_cur;

            ++rc_locked_len;
        }

        // --------------------------------------------------------
        // 7. SI EL REVERSO NO PUDO EXTENDERSE COMPLETAMENTE
        // --------------------------------------------------------

        if (!extend_full) {

            rc_end = d_rcEdge[cur_edge];

            if (rc_end == UINT32_MAX) {

                // -----------------------------------------------
                // Rollback del camino directo
                // -----------------------------------------------

                uint32_t rollback_edge = (uint32_t)edge_idx;

                for (uint32_t i = 0; i < locked_len; ++i) {

                    rollback_edge = d_prevEdge[rollback_edge];

                    if (rollback_edge == UINT32_MAX)
                        break;

                    UnlockBit(d_locks, rollback_edge);
                }

                // -----------------------------------------------
                // Rollback del reverse complement
                // -----------------------------------------------

                uint32_t rollback_rc = rc_start;

                for (uint32_t i = 0; i < rc_locked_len; ++i) {

                    rollback_rc = d_nextEdge[rollback_rc];

                    if (rollback_rc == UINT32_MAX)
                        break;

                    UnlockBit(d_locks, rollback_rc);
                }

                // edge_idx fue adquirido por este hilo.
                UnlockBit(d_locks, edge_idx);

                // rc_start también fue adquirido por este hilo.
                UnlockBit(d_locks, rc_start);

                return;
            }
        }
    }

    // ------------------------------------------------------------
    // 8. GUARDAR EL VÉRTICE / UNITIG
    // ------------------------------------------------------------

    unsigned int idx = atomicAdd(d_vertex_counter, 1);

    if (idx >= numEdges) {
        /*
         * Mantenemos por ahora el mismo límite que tenía
         * tu implementación original.
         *
         * IMPORTANTE:
         * posteriormente conviene reemplazar numEdges por
         * la capacidad REAL de d_vertices.
         */
        return;
    }

    d_vertices[idx * 6 + 0] = cur_edge;
    d_vertices[idx * 6 + 1] = (uint32_t)edge_idx;
    d_vertices[idx * 6 + 2] = rc_start;
    d_vertices[idx * 6 + 3] = rc_end;
    d_vertices[idx * 6 + 4] = depth;
    d_vertices[idx * 6 + 5] = length;

    atomicAdd(
        d_count_palindrome,
        (cur_edge == rc_start) ? 1 : 0
    );
}

// ========== KERNEL PARA SIMPLE PATHS ==========
/*__global__ void procesarCaminosSimples(
    uint64_t* d_isValidEdgeBits, uint32_t* d_nextEdge, uint32_t* d_prevEdge,
    uint32_t* d_rcEdge, uint16_t* d_edgeMultiplicity, uint32_t numEdges,
    int* d_count_palindrome, uint64_t* d_locks,
    uint32_t* d_vertices, unsigned int* d_vertex_counter) {

    uint64_t edge_idx = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    const uint32_t MAX_VERTICES_GPU = numEdges;

    if (edge_idx >= MAX_VERTICES_GPU) return;

    if (!IsValidEdgeBit(d_isValidEdgeBits, edge_idx)|| d_nextEdge[edge_idx] != UINT32_MAX) return;

    //if (!d_isValidEdge[edge_idx] || d_nextEdge[edge_idx] != UINT32_MAX) return;

    // Intentar bloquear el nodo inicial
    //if (atomicCAS(&d_locks[edge_idx], 0, 1) != 0) return;

    if (!TryLockBit(d_locks, edge_idx)) return;

    uint32_t cur_edge = edge_idx;
    uint32_t prev_edge;
    uint32_t depth = d_edgeMultiplicity[edge_idx];
    uint32_t length = 1;

    const int max_path = 15000;//8744;//numEdges*(2.83/100);
    uint32_t locked[max_path];
    int locked_len = 0;
    bool will_be_added = true;

    // Caminamos hacia atrás (PrevSimplePathEdge)
    while ((prev_edge = d_prevEdge[cur_edge]) != UINT32_MAX) {
        cur_edge = prev_edge;

//atomicCAS(&d_locks[cur_edge], 0, 1) != 0
        if (!TryLockBit(d_locks, cur_edge)) {
            will_be_added = false;
            break;
        }

        locked[locked_len] = cur_edge;
        ++locked_len;
        depth += d_edgeMultiplicity[cur_edge];
        ++length;

        if (locked_len >= max_path) {
            will_be_added = false;
            break;
        }
    }

if (!will_be_added) {
    for (int i = 0; i < locked_len; i++)
        UnlockBit(d_locks, locked[i]);

    UnlockBit(d_locks, edge_idx);
    return;
}

// Control de reverso
uint32_t rc_start = d_rcEdge[edge_idx];

if (rc_start == UINT32_MAX) {
    for (int i = 0; i < locked_len; i++)
        UnlockBit(d_locks, locked[i]);

    UnlockBit(d_locks, edge_idx);
    return;
}

uint32_t rc_end;
bool extend_full = true;

// control del reverso end
if (!TryLockBit(d_locks, rc_start)) {

    rc_end = d_rcEdge[cur_edge];

    if (rc_end == UINT32_MAX ||
        umax_u32(edge_idx, cur_edge) < umax_u32(rc_start, rc_end)) {

        for (int i = 0; i < locked_len; i++)
            UnlockBit(d_locks, locked[i]);

        UnlockBit(d_locks, edge_idx);

        // IMPORTANTE:
        // acá NO se desbloquea rc_start porque TryLockBit falló,
        // entonces este hilo nunca adquirió ese lock.
        return;
    }

} else {
    // Caminamos por el reverso
    rc_end = rc_start;
    uint32_t rc_cur = rc_start;
    int rc_locked_len = 0;

    while ((rc_cur = d_nextEdge[rc_cur]) != UINT32_MAX) {
        rc_end = rc_cur;

        if (!TryLockBit(d_locks, rc_cur)) {
            extend_full = false;
            break;
        }

        if ((locked_len + rc_locked_len) >= max_path) {
            UnlockBit(d_locks, rc_cur);  // porque ya lo habíamos bloqueado
            extend_full = false;
            break;
        }

        locked[locked_len + rc_locked_len] = rc_cur;
        ++rc_locked_len;
    }

    if (!extend_full) {
        rc_end = d_rcEdge[cur_edge];

        if (rc_end == UINT32_MAX) {
            // rollback reverso y camino
            for (int i = 0; i < locked_len + rc_locked_len; i++)
                UnlockBit(d_locks, locked[i]);

            UnlockBit(d_locks, edge_idx);
            UnlockBit(d_locks, rc_start);
            return;
        }
    }
}
    // Guardar vértice
    unsigned int idx = atomicAdd(d_vertex_counter, 1);
    if (idx >= numEdges) return;

    d_vertices[idx * 6 + 0] = cur_edge;
    d_vertices[idx * 6 + 1] = edge_idx;
    d_vertices[idx * 6 + 2] = rc_start;
    d_vertices[idx * 6 + 3] = rc_end;
    d_vertices[idx * 6 + 4] = (uint32_t)depth;
    d_vertices[idx * 6 + 5] = (uint32_t)length;
   // d_vertices[idx * 7 + 6] = 0;

    atomicAdd(d_count_palindrome, (cur_edge == rc_start) ? 1 : 0);
}*/

//uint8_t* d_isValidEdge
/*__global__ void procesarLoops(
    uint64_t* d_isValidEdgeBits,
    uint32_t* d_prevEdge,
    uint32_t* d_nextEdge,
    uint32_t* d_rcEdge,
    uint16_t* d_edgeMultiplicity,
    uint64_t* d_locks,
    uint32_t numEdges,
    uint32_t* d_vertices,
    unsigned int* d_vertex_counter) {

    uint32_t edge_idx = (uint32_t)((uint64_t)blockIdx.x * blockDim.x + threadIdx.x);
    const uint32_t MAX_VERTICES_GPU = numEdges;

    if (edge_idx >= MAX_VERTICES_GPU) return;

    if (!IsValidEdgeBit(d_isValidEdgeBits, edge_idx)) return;

    // NO bloquear edge_idx si el reverso ya está bloqueado
    uint32_t rc_edge = d_rcEdge[edge_idx];

    if (rc_edge == UINT32_MAX) return;

    if (IsLockedBit(d_locks, rc_edge)) return;

    // Intentar bloquear edge_idx
    if (!TryLockBit(d_locks, edge_idx)) return;

    uint32_t start_edge = edge_idx;
    uint32_t cur_edge = edge_idx;

    int32_t depth = d_edgeMultiplicity[cur_edge]*2;
    uint32_t length = 1;

    const int max_path_len = 15000;//736;

    uint32_t locked[max_path_len];
    int lock_count = 0;

    locked[lock_count] = cur_edge;
    ++lock_count;

    bool valid_loop = false;

    // Caminá hacia atrás, bloqueando
    while (true) {
        uint32_t prev = d_prevEdge[cur_edge];

        if (prev == UINT32_MAX) break;

        if (prev == start_edge) {
            valid_loop = true;
            break;
        }

        if (!TryLockBit(d_locks, prev)) {
            break;
        }

        if (lock_count >= max_path_len) {
            UnlockBit(d_locks, prev);
            break;
        }

        locked[lock_count] = prev;
        ++lock_count;

        cur_edge = prev;
        depth += d_edgeMultiplicity[cur_edge];
        ++length;
    }

    if (!valid_loop) {
        for (int i = 0; i < lock_count; i++) {
            UnlockBit(d_locks, locked[i]);
        }
        return;
    }

    // Guardar el vértice representativo del loop
    uint32_t rc_start = d_rcEdge[edge_idx];
    uint32_t rc_end   = d_rcEdge[cur_edge];
    uint32_t start    = d_nextEdge[edge_idx];
    uint32_t end      = edge_idx;

    if (rc_start == UINT32_MAX || rc_end == UINT32_MAX || start == UINT32_MAX) {
        for (int i = 0; i < lock_count; i++) {
            UnlockBit(d_locks, locked[i]);
        }
        return;
    }

    // Marcar los reversos como bloqueados para evitar duplicados
    for (int i = 0; i < lock_count; ++i) {
        uint32_t rc = d_rcEdge[locked[i]];
        if (rc != UINT32_MAX) {
            ForceLockBit(d_locks, rc);
        }
    }

    unsigned int idx = atomicAdd(d_vertex_counter, 1);

    if (idx >= MAX_VERTICES_GPU) {
        // Acá ya no conviene liberar los locks si el buffer se llenó,
        // porque el estado queda inconsistente de todas formas.
        return;
    }

    d_vertices[idx * 6 + 0] = start;
    d_vertices[idx * 6 + 1] = end;
    d_vertices[idx * 6 + 2] = rc_start;
    d_vertices[idx * 6 + 3] = rc_end;
    d_vertices[idx * 6 + 4] = (uint32_t)depth;
    d_vertices[idx * 6 + 5] = (uint32_t)length;
}*/


// ========== KERNEL PARA LOOPS - SIN max_path_len NI locked[] ==========
__global__ void procesarLoops(
    uint64_t* d_isValidEdgeBits,
    uint32_t* d_prevEdge,
    uint32_t* d_nextEdge,
    uint32_t* d_rcEdge,
    uint16_t* d_edgeMultiplicity,
    uint64_t* d_locks,
    uint32_t numEdges,
    uint32_t* d_vertices,
    unsigned int* d_vertex_counter) {

    uint32_t edge_idx =
        (uint32_t)((uint64_t)blockIdx.x * blockDim.x + threadIdx.x);

    const uint32_t MAX_VERTICES_GPU = numEdges;

    if (edge_idx >= MAX_VERTICES_GPU)
        return;

    if (!IsValidEdgeBit(d_isValidEdgeBits, edge_idx))
        return;

    // ------------------------------------------------------------
    // 1. CONTROL DEL REVERSE COMPLEMENT
    // ------------------------------------------------------------

    // No bloquear edge_idx si el reverso ya está bloqueado
    uint32_t rc_edge = d_rcEdge[edge_idx];

    if (rc_edge == UINT32_MAX)
        return;

    if (IsLockedBit(d_locks, rc_edge))
        return;

    // ------------------------------------------------------------
    // 2. INTENTAR BLOQUEAR LA ARISTA INICIAL
    // ------------------------------------------------------------

    if (!TryLockBit(d_locks, edge_idx))
        return;

    uint32_t start_edge = edge_idx;
    uint32_t cur_edge = edge_idx;

    int32_t depth = d_edgeMultiplicity[cur_edge] * 2;
    uint32_t length = 1;

    /*
     * Cantidad de aristas bloqueadas por este hilo.
     *
     * A diferencia de procesarCaminosSimples,
     * acá edge_idx/start_edge SÍ está incluido.
     */
    uint32_t lock_count = 1;

    bool valid_loop = false;

    // ------------------------------------------------------------
    // 3. RECORRER HACIA ATRÁS BUSCANDO CERRAR EL LOOP
    // ------------------------------------------------------------

    while (true) {

        uint32_t prev = d_prevEdge[cur_edge];

        // El camino terminó sin cerrar un ciclo.
        if (prev == UINT32_MAX)
            break;

        // Volvimos al punto inicial:
        // encontramos un loop completo.
        if (prev == start_edge) {
            valid_loop = true;
            break;
        }

        // Intentar adquirir esta arista.
        if (!TryLockBit(d_locks, prev))
            break;

        /*
         * El lock pertenece ahora a este hilo.
         * Ya no necesitamos guardar prev en locked[].
         */
        ++lock_count;

        cur_edge = prev;

        depth += d_edgeMultiplicity[cur_edge];
        ++length;
    }

    // ------------------------------------------------------------
    // 4. SI NO ERA UN LOOP VÁLIDO, HACER ROLLBACK
    // ------------------------------------------------------------

    if (!valid_loop) {

        /*
         * Volvemos a recorrer exactamente lock_count aristas
         * comenzando en start_edge.
         *
         * start_edge está incluido en lock_count.
         */
        uint32_t rollback_edge = start_edge;

        for (uint32_t i = 0; i < lock_count; ++i) {

            UnlockBit(d_locks, rollback_edge);

            /*
             * No necesitamos avanzar después de la última
             * arista que acabamos de liberar.
             */
            if (i + 1 < lock_count) {

                rollback_edge = d_prevEdge[rollback_edge];

                /*
                 * En un grafo consistente esto no debería ocurrir,
                 * porque previamente recorrimos exactamente estas
                 * mismas aristas.
                 */
                if (rollback_edge == UINT32_MAX)
                    break;
            }
        }

        return;
    }

    // ------------------------------------------------------------
    // 5. CONSTRUIR INFORMACIÓN DEL VÉRTICE REPRESENTATIVO
    // ------------------------------------------------------------

    uint32_t rc_start = d_rcEdge[edge_idx];
    uint32_t rc_end   = d_rcEdge[cur_edge];
    uint32_t start    = d_nextEdge[edge_idx];
    uint32_t end      = edge_idx;

    if (rc_start == UINT32_MAX ||
        rc_end   == UINT32_MAX ||
        start    == UINT32_MAX) {

        // Rollback de todas las aristas adquiridas.
        uint32_t rollback_edge = start_edge;

        for (uint32_t i = 0; i < lock_count; ++i) {

            UnlockBit(d_locks, rollback_edge);

            if (i + 1 < lock_count) {

                rollback_edge = d_prevEdge[rollback_edge];

                if (rollback_edge == UINT32_MAX)
                    break;
            }
        }

        return;
    }

    // ------------------------------------------------------------
    // 6. BLOQUEAR LOS REVERSE COMPLEMENTS
    // ------------------------------------------------------------

    /*
     * Antes se hacía:
     *
     * for (int i = 0; i < lock_count; ++i) {
     *     uint32_t rc = d_rcEdge[locked[i]];
     *     ...
     * }
     *
     * Ahora volvemos a recorrer el mismo loop mediante prevEdge.
     */

    uint32_t walk_edge = start_edge;

    for (uint32_t i = 0; i < lock_count; ++i) {

        uint32_t rc = d_rcEdge[walk_edge];

        if (rc != UINT32_MAX) {
            ForceLockBit(d_locks, rc);
        }

        if (i + 1 < lock_count) {

            walk_edge = d_prevEdge[walk_edge];

            /*
             * No debería ocurrir si el loop que acabamos
             * de recorrer permanece consistente.
             */
            if (walk_edge == UINT32_MAX)
                break;
        }
    }

    // ------------------------------------------------------------
    // 7. GUARDAR EL VÉRTICE REPRESENTATIVO DEL LOOP
    // ------------------------------------------------------------

    unsigned int idx = atomicAdd(d_vertex_counter, 1);

    if (idx >= MAX_VERTICES_GPU) {

        /*
         * Conservamos por ahora el mismo comportamiento
         * de tu implementación original.
         *
         * Si el buffer se llenó, el estado ya no puede
         * recuperarse limpiamente porque también se marcaron
         * los reverse complements.
         */
        return;
    }

    d_vertices[idx * 6 + 0] = start;
    d_vertices[idx * 6 + 1] = end;
    d_vertices[idx * 6 + 2] = rc_start;
    d_vertices[idx * 6 + 3] = rc_end;
    d_vertices[idx * 6 + 4] = (uint32_t)depth;
    d_vertices[idx * 6 + 5] = length;
}



   /*
    __global__ void marcarNeedRC_SimplePaths(
    const uint8_t* d_isValidEdge,
    const uint64_t* d_nextEdge,
    const uint64_t* d_prevEdge,
    uint64_t numEdges, char* d_need_rc,int* d_locks) {
    
    uint64_t edge_idx = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (edge_idx >= numEdges) return;
    
    if (atomicCAS(&d_locks[edge_idx], 0, 1) != 0) return;

    if (!d_isValidEdge[edge_idx]) return;
    if (d_nextEdge[edge_idx] != UINT64_MAX) return;
    

    uint64_t cur_edge = edge_idx;
    const int max_path = 6500;
    int steps = 0;

    while (true) {
        uint64_t prev = d_prevEdge[cur_edge];
        if (prev == UINT64_MAX) break;
        atomicExch(&d_locks[prev], 1);
        cur_edge = prev;
        if (++steps >= max_path) break;
        
    }

    d_need_rc[edge_idx] = 1;
    d_need_rc[cur_edge] = 1;
    
    atomicExch(&d_locks[cur_edge], 1);
    
    */
    	 /*   uint64_t edge_idx = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    	        	    
	    if (edge_idx >= numEdges) return;
	    
	    if (atomicCAS(&d_locks[edge_idx], 0, 1) != 0) return;
	    
	    if (!d_isValidEdge[edge_idx]) return;
	    if (d_nextEdge[edge_idx] != UINT64_MAX) return;
	    
	    const int max_path_len = 7500;//6500;

            uint64_t cur   = edge_idx;


	   for (int i = 0; i < max_path_len; i++) {

		d_need_rc[cur] = 1;
	   	if (atomicCAS(&d_locks[cur], 0, 1) != 0) break;
		
		 
		cur= d_prevEdge[cur];
		

		if (cur == UINT64_MAX) break;
	    }*/
	    

    
//}



/*
__global__ void marcarNeedRC_Loops( const uint8_t* d_isValidEdge, const uint64_t* d_prevEdge, uint64_t numEdges, char* d_need_rc, int *d_locks) {
    uint64_t edge_idx = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (edge_idx >= numEdges) return;

    if (atomicCAS(&d_locks[edge_idx], 0, 1) != 0) return;

    if (!d_isValidEdge[edge_idx]) return;

    const int max_path_len = 750;

    uint64_t start = edge_idx;
    uint64_t cur   = edge_idx;

    bool valid_loop = false;

    for (int step = 0; step < max_path_len; ++step) {
        uint64_t prev = d_prevEdge[cur];
        if (prev == UINT64_MAX) break;
    //    atomicExch(&d_locks[prev], 1);
        if (prev == start) {
            valid_loop = true;
            break;
        }
        cur = prev;
    }

    if (valid_loop) {
        d_need_rc[start] = 1;
        d_need_rc[cur]   = 1;
        atomicExch(&d_locks[cur], 1);
    }
    */
    /*    uint64_t edge_idx = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (edge_idx >= numEdges) return;
    
    if (atomicCAS(&d_locks[edge_idx], 0, 1) != 0) return;
    	    
    if (!d_isValidEdge[edge_idx]) return;

    const int max_path_len = 750;//6500;
    uint64_t camino[max_path_len];
    int usado = 0;

    uint64_t cur   = edge_idx;

    bool valid_loop = false;

    for (int i = 0; i < max_path_len; i++) {
	camino[i] = cur;
	usado++;
        

	 
        cur= d_prevEdge[cur];
        if (cur == UINT64_MAX) break;

        if (cur == edge_idx) {
            valid_loop = true;
            break;
        }
        
       if (atomicCAS(&d_locks[cur], 0, 1) != 0) break;;
    }

    if (valid_loop) {
	for (int i = 0; i < usado; i++) {
	   d_need_rc[camino[i]] = 1;
        }
    }*/
//}









// ========== KERNEL PARA SIMPLE PATHS (solo recolectar RC requeridos) ==========
/*__global__ void procesarCaminosSimples_rc(
    uint8_t* d_isValidEdge, uint64_t* d_nextEdge, uint64_t* d_prevEdge,
    uint64_t* d_rcEdge, int64_t* d_edgeMultiplicity, uint64_t numEdges,
    int* d_count_palindrome, int* d_locks,
    uint64_t* d_calcRC, unsigned int* d_calcRC_vertex) {

    uint64_t edge_idx = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    const uint64_t MAX_VERTICES_GPU = numEdges;

    if (edge_idx >= MAX_VERTICES_GPU) return;

    if (!d_isValidEdge[edge_idx] || d_nextEdge[edge_idx] != UINT64_MAX) return;

    if (atomicCAS(&d_locks[edge_idx], 0, 1) != 0) return;

    uint64_t cur_edge = edge_idx;
    uint64_t prev_edge;

    const int max_path = 6500;
    uint64_t locked[max_path];
    int locked_len = 0;
    bool will_be_added = true;

    while ((prev_edge = d_prevEdge[cur_edge]) != UINT64_MAX) {
        cur_edge = prev_edge;

        if (atomicCAS(&d_locks[cur_edge], 0, 1) != 0) {
            will_be_added = false;
            break;
        }

        locked[locked_len] = cur_edge;
        ++locked_len;

        if (locked_len >= max_path) {
            will_be_added = false;
            break;
        }
    }

    if (!will_be_added) {
        for (int i = 0; i < locked_len; i++)
            atomicExch(&d_locks[locked[i]], 0);
        atomicExch(&d_locks[edge_idx], 0);
        return;
    }

    uint64_t rc_start = d_rcEdge[edge_idx];

    // necesito RC del edge_idx
    unsigned int idx = atomicAdd(d_calcRC_vertex, 1);
    if (idx < numEdges) d_calcRC[idx] = edge_idx;

    if (rc_start == UINT64_MAX) {
        for (int i = 0; i < locked_len; i++)
            atomicExch(&d_locks[locked[i]], 0);
        atomicExch(&d_locks[edge_idx], 0);
        return;
    }

    if (atomicCAS(&d_locks[rc_start], 0, 1) != 0) {
        // rc_end = d_rcEdge[cur_edge] (en tu lógica)
        // necesito RC del cur_edge
        idx = atomicAdd(d_calcRC_vertex, 1);
        if (idx < numEdges) d_calcRC[idx] = cur_edge;
    }
}

__global__ void procesarLoops_rc(
    uint8_t* d_isValidEdge, uint64_t* d_prevEdge, uint64_t* d_nextEdge,
    uint64_t* d_rcEdge, int64_t* d_edgeMultiplicity,
    int* d_locks, uint64_t numEdges,
    uint64_t* d_calcRC, unsigned int* d_calcRC_vertex) {

    uint64_t edge_idx = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    const uint64_t MAX_VERTICES_GPU = numEdges;

    if (edge_idx >= MAX_VERTICES_GPU) return;
    if (!d_isValidEdge[edge_idx]) return;

    if (atomicCAS(&d_locks[edge_idx], 0, 1) != 0) return;

    uint64_t start_edge = edge_idx;
    uint64_t cur_edge = edge_idx;

    const int max_path_len = 6500;
    uint64_t locked[max_path_len];
    int lock_count = 0;
    locked[lock_count++] = cur_edge;

    bool valid_loop = false;

    while (true) {
        uint64_t prev = d_prevEdge[cur_edge];
        if (prev == UINT64_MAX) break;

        if (prev == start_edge) {
            valid_loop = true;
            break;
        }

        if (atomicCAS(&d_locks[prev], 0, 1) != 0) break;

        locked[lock_count++] = prev;
        cur_edge = prev;

        if (lock_count >= max_path_len) break;
    }

    if (!valid_loop) {
        for (int i = 0; i < lock_count; i++)
            atomicExch(&d_locks[locked[i]], 0);
        return;
    }

    // necesito RC del edge_idx y cur_edge
    unsigned int idx = atomicAdd(d_calcRC_vertex, 1);
    if (idx < numEdges) d_calcRC[idx] = edge_idx;

    idx = atomicAdd(d_calcRC_vertex, 1);
    if (idx < numEdges) d_calcRC[idx] = cur_edge;

    // marco también cada locked[i]
    for (int i = 0; i < lock_count; ++i) {
        if (locked[i] != UINT64_MAX) {
            idx = atomicAdd(d_calcRC_vertex, 1);
            if (idx < numEdges) d_calcRC[idx] = locked[i];
        }
    }
}
*/
// ----------------- WRAPPERS HOST -----------------

void GPU_procesarCaminosSimples(
    uint64_t* d_isValidEdgeBits, uint32_t* d_nextEdge, uint32_t* d_prevEdge,
    uint32_t* d_rcEdge, uint16_t* d_edgeMultiplicity, uint32_t numEdges,
    int* d_count_palindrome, uint64_t* d_locks,
    uint32_t* d_vertices, unsigned int* d_vertex_counter,
    int blockSize/*,cudaStream_t stream*/) {

    int grid = grid_for(numEdges, blockSize);
    procesarCaminosSimples<<<grid, blockSize/*,0,stream*/>>>(
        d_isValidEdgeBits, d_nextEdge, d_prevEdge,
        d_rcEdge, d_edgeMultiplicity, numEdges,
        d_count_palindrome, d_locks,
        d_vertices, d_vertex_counter
    );
    GPU_checkLastCuda("procesarCaminosSimples");
}

void GPU_procesarLoops(
    uint64_t* d_isValidEdgeBits,uint32_t* d_prevEdge, uint32_t* d_nextEdge,
    uint32_t* d_rcEdge, uint16_t* d_edgeMultiplicity,
    uint64_t* d_locks, uint32_t numEdges,
    uint32_t* d_vertices, unsigned int* d_vertex_counter,
    int blockSize/*,cudaStream_t stream*/) {

    int grid = grid_for(numEdges, blockSize);
    procesarLoops<<<grid, blockSize/*,0,stream*/>>>(
        d_isValidEdgeBits, d_prevEdge, d_nextEdge,
        d_rcEdge, d_edgeMultiplicity,
        d_locks, numEdges,
        d_vertices, d_vertex_counter
    );
    GPU_checkLastCuda("procesarLoops");
}

