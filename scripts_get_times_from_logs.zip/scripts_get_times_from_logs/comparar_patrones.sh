#!/usr/bin/env bash
set -euo pipefail

# Número de ejecución recibido por parámetro
NRO_EJECUCION="${1:-1}"

OUT_DIR="./comparaciones_logs"
mkdir -p "$OUT_DIR"

# Ir a la carpeta donde está este script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PYTHON_BIN="${PYTHON_BIN:-python3}"
SUMADOR="./sumar_tiempos.py"

GPU_DIR="./test_output_gpu"
GPU_PATTERNS="$GPU_DIR/patrones_gpu.txt"

CPU_DIR="./test_output_orig"
CPU_PATTERNS="$CPU_DIR/patrones_cpu.txt"

run_batch () {
  local base_dir="$1"
  local patterns="$2"
  local tag="$3"

  echo "=== Procesando $tag ==="
  for i in "$NRO_EJECUCION"; do
    local log_path="$base_dir/$i/log"
    local csv_out="$OUT_DIR/${tag}_${i}.csv"

    if [[ ! -f "$log_path" ]]; then
      echo "  [WARN] No existe: $log_path (salteo)"
      continue
    fi

    echo "  - $tag corrida $i"
    "$PYTHON_BIN" "$SUMADOR" "$log_path" "$patterns" "$csv_out" | tee "$OUT_DIR/${tag}_${i}.txt"
  done
  echo
}

run_batch "$GPU_DIR" "$GPU_PATTERNS" "gpu"
run_batch "$CPU_DIR" "$CPU_PATTERNS" "orig"


