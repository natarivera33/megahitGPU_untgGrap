__device__ __forceinline__ uint8_t GetW_device(const uint8_t* d_w, uint64_t x) {
    return d_w[x];
}

__device__ __forceinline__ bool GetBit64(const uint64_t* bits, uint64_t x) {
    return (bits[x >> 6] >> (x & 63)) & 1ULL;
}

__device__ __forceinline__ bool IsTip_device(const uint64_t* d_tip_bits, uint64_t x) {
    return GetBit64(d_tip_bits, x);
}

__device__ __forceinline__ bool IsLastOrTip_device(const uint64_t* d_last_bits,
                                                   const uint64_t* d_tip_bits,
                                                   uint64_t x) {
    return GetBit64(d_last_bits, x) || GetBit64(d_tip_bits, x);
}

__device__ __forceinline__ uint64_t Backward_device(const uint64_t* d_backward, uint64_t x) {
    return d_backward[x];
}

__device__ __forceinline__ uint64_t GetLastIndex_device(const uint64_t* d_lastIndex, uint64_t x) {
    return d_lastIndex[x];
}

template<int KMAX>
__device__ void GetLabel_device(uint64_t id,
                                uint8_t* seq,
                                int k,
                                const uint8_t* d_w,
                                const uint64_t* d_backward,
                                const uint64_t* d_tip_bits
                                /* TODO: tip_labels */) {

    uint64_t x = id;
    for (int i = k - 1; i >= 0; --i) {
        if (IsTip_device(d_tip_bits, x)) {
            // TODO: portar TipLabelStartPtr/CharAtTipLabel
            // Por ahora: dejarlo sin soportar o retornar algo especial
            seq[i] = 1; // placeholder
            break;
        }
        x = Backward_device(d_backward, x);
        uint8_t c = GetW_device(d_w, x);
        if (c > 4) c -= 4;      // kAlphabetSize=4 (A,C,G,T como 1..4)
        seq[i] = c;
    }
}

struct Range { uint64_t l, r; };

template<int KMAX>
__device__ uint64_t IndexBinarySearch_device(
    const uint8_t* seq, int k,
    const Range* d_prefix_lookup, uint64_t prefix_lookup_size,
    const uint8_t* d_w,
    const uint64_t* d_backward,
    const uint64_t* d_lastIndex,
    const uint64_t* d_tip_bits
    /* TODO tip_labels, last_bits si tu comparación usa tips/last */
) {
    // Construir prefix (mismo criterio que CPU: ojo con kBitsPerChar si aplica)
    // Simplificación: si ya tenés en CPU el mapeo de prefix->range, copiás tal cual.
    uint64_t prefix = 0;
    // TODO: replicar exactamente el cálculo real de prefix (depende de kBitsPerChar)
    // Placeholder: usar primeros p caracteres:
    int p = 0;
    // p debe ser el mismo que en CPU (según prefix_look_up_.size()).
    // Para empezar, podés hardcodear p=2/3 para validar.

    // Range l,r desde lookup (ojo bounds)
    Range rg = d_prefix_lookup[prefix];
    uint64_t l = rg.l, r = rg.r;

    while (l <= r) {
        uint64_t mid = (l + r) >> 1;
        uint64_t y = mid;
        int cmp = 0;

        for (int i = k - 1; i >= 0; --i) {
            if (IsTip_device(d_tip_bits, y)) {
                // TODO: comparación contra tip label (fase 2)
                cmp = -1;
                break;
            }

            y = Backward_device(d_backward, y);
            uint8_t c = GetW_device(d_w, y);

            if (c < seq[i]) { cmp = -1; break; }
            if (c > seq[i]) { cmp =  1; break; }
        }

        if (cmp == 0) {
            return GetLastIndex_device(d_lastIndex, mid);
        } else if (cmp > 0) {
            if (mid == 0) break;
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    return UINT64_MAX;
}

template<int KMAX>
__device__ uint64_t EdgeReverseComplement_device(
    uint64_t edge_id, int k,
    const uint8_t* d_w,
    const uint64_t* d_last_bits,
    const uint64_t* d_tip_bits,
    const uint64_t* d_backward,
    const uint64_t* d_lastIndex,
    const Range* d_prefix_lookup, uint64_t prefix_lookup_size
) {
    uint8_t w = GetW_device(d_w, edge_id);
    if (w == 0) return UINT64_MAX;

    uint8_t seq[KMAX + 1];
    GetLabel_device<KMAX>(edge_id, seq, k, d_w, d_backward, d_tip_bits);
    seq[k] = w;
    if (seq[k] > 4) seq[k] -= 4;

    // reverse
    for (int i = 0, j = k; i < j; ++i, --j) {
        uint8_t tmp = seq[i]; seq[i] = seq[j]; seq[j] = tmp;
    }
    // complement:  A<->T, C<->G  (si codificás 1..4)
    for (int i = 0; i < k + 1; ++i) {
        seq[i] = 5 - seq[i];
    }

    uint64_t rev_node = IndexBinarySearch_device<KMAX>(
        seq, k,
        d_prefix_lookup, prefix_lookup_size,
        d_w, d_backward, d_lastIndex, d_tip_bits
    );
    if (rev_node == UINT64_MAX) return UINT64_MAX;

    // scan hacia atrás hasta last/tip
    while (true) {
        uint8_t edge_label = GetW_device(d_w, rev_node);
        uint8_t target = seq[k];
        if (edge_label == target || (edge_label > 4 && edge_label - 4 == target)) {
            return rev_node;
        }
        if (rev_node == 0) break;
        rev_node--;
        if (IsLastOrTip_device(d_last_bits, d_tip_bits, rev_node)) break;
    }
    return UINT64_MAX;
}

__global__ void kernel_calcular_rcEdge(
    uint64_t* d_rcEdge,
    const uint64_t* d_isValidEdge,
    uint64_t n,

    int k,
    const uint8_t* d_w,
    const uint64_t* d_last_bits,
    const uint64_t* d_tip_bits,
    const uint64_t* d_backward,
    const uint64_t* d_lastIndex,
    const Range* d_prefix_lookup, uint64_t prefix_lookup_size
) {
    uint64_t i = (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    if (!d_isValidEdge[i]) { d_rcEdge[i] = UINT64_MAX; return; }

    d_rcEdge[i] = EdgeReverseComplement_device<256>(
        i, k, d_w, d_last_bits, d_tip_bits, d_backward, d_lastIndex,
        d_prefix_lookup, prefix_lookup_size
    );
}



