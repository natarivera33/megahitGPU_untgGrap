//#include "sdbg.h"

#include <chrono>
using Clock = std::chrono::high_resolution_clock;

// src/sdbg/sdbg.cpp
#include "sdbg/sdbg.h"
constexpr uint64_t SDBG::kNullID;
constexpr uint32_t SDBG::kNullID32;


void LoadNeedRCForSimplePaths(SDBG* sdbg) {
    const uint32_t real_n = sdbg->size();
    std::vector<uint32_t> rc_cache(real_n, SDBG::kNullID32);

    auto normalize = [real_n](uint32_t x) -> uint32_t {
        return (x == SDBG::kNullID32 || x >= real_n) ? SDBG::kNullID32 : x;
    };

    auto get_rc = [&](uint32_t e) -> uint32_t {
        if (e == SDBG::kNullID32 || e >= real_n) return SDBG::kNullID32;

        uint32_t cached = rc_cache[e];
        if (cached != SDBG::kNullID32) return cached;

        uint32_t rc = normalize(sdbg->EdgeReverseComplement32(e));
        rc_cache[e] = rc;
        return rc;
    };

    #pragma omp parallel for schedule(guided, 1024)
    for (uint32_t edge_idx = 0; edge_idx < real_n; edge_idx++) {
      //  if (sdbg->host_is_valid_edge[edge_idx] != 1) continue;
        if (!sdbg->GetHostIsValidEdge(edge_idx)) continue;
        if (sdbg->host_rc_edge[edge_idx] != SDBG::kNullID32) continue;

        bool is_tail = (sdbg->host_next_edge[edge_idx] == SDBG::kNullID32);
        bool is_head = (sdbg->host_prev_edge[edge_idx] == SDBG::kNullID32);

        if (!is_tail && !is_head) continue;

        uint32_t rc = get_rc(edge_idx);
        if (rc == SDBG::kNullID32) continue;

        sdbg->host_rc_edge[edge_idx] = rc;
        sdbg->host_rc_edge[rc] = edge_idx;
    }
}






void LoadNeedRCForLoops(SDBG* sdbg) {
    const uint32_t real_n = sdbg->size();
    const uint32_t max_loop_len = real_n*(2.46/100);;//736;   // o el máximo que mediste
    AtomicBitVector locks(real_n);

    auto normalize = [real_n](uint32_t x) -> uint32_t {
        return (x == SDBG::kNullID32 || x >= real_n) ? SDBG::kNullID32 : x;
    };

    #pragma omp parallel for schedule(dynamic, 1024)
    for (uint32_t edge_idx = 0; edge_idx < real_n; ++edge_idx) {
        if (!sdbg->GetHostIsValidEdge(edge_idx)) continue;
        if (sdbg->host_rc_edge[edge_idx] != SDBG::kNullID32) continue;
        if (locks.at(edge_idx)) continue;

        uint32_t cur_edge = edge_idx;
        bool valid_loop = true;
        uint32_t steps = 0;

        while (!locks.at(cur_edge)) {
            locks.set(cur_edge);

            uint32_t prev = normalize(sdbg->host_prev_edge[cur_edge]);
            if (prev == SDBG::kNullID32) {
                valid_loop = false;
                break;
            }

            cur_edge = prev;
            ++steps;

            if (steps > max_loop_len) {
                valid_loop = false;
                break;
            }
        }

        if (!valid_loop) continue;
        if (cur_edge != edge_idx) continue;

        uint32_t start = normalize(sdbg->host_next_edge[edge_idx]);
        if (start == SDBG::kNullID32) continue;
        if (sdbg->host_rc_edge[start] != SDBG::kNullID32) continue;

        uint32_t rc_end = normalize(sdbg->EdgeReverseComplement32(edge_idx));
        if (rc_end == SDBG::kNullID32) continue;
        else sdbg->host_rc_edge[rc_end] = edge_idx;
        
         sdbg->host_rc_edge[edge_idx] = rc_end;

        if (sdbg->host_rc_edge[start] != SDBG::kNullID32) continue;

        uint32_t rc_start = normalize(sdbg->EdgeReverseComplement32(start));
        if (rc_start == SDBG::kNullID32) continue;
	else sdbg->host_rc_edge[rc_start]    = start;
        sdbg->host_rc_edge[start]    = rc_start;
    }
}


void SDBG::reservarMemoriaGPU(uint32_t numEdges){
//	cudaMalloc(&this->d_isValidEdge,      numEdges * sizeof(uint8_t));//ver asincrono  comprimir pasar a 1 bit

        size_t num_words = (numEdges + 63) >> 6;
       xinfoc("---GPU---prepararEjecucionGPU_hallarCamSimples_Loops---numEdges:{} num_words:{}\n", numEdges,num_words);
        
        cudaMalloc(&d_isValidEdgeBits, num_words * sizeof(uint64_t));
              
	cudaMalloc(&this->d_nextEdge,         numEdges * sizeof(uint32_t));
	cudaMalloc(&this->d_prevEdge,         numEdges * sizeof(uint32_t));
	cudaMalloc(&this->d_rcEdge,           numEdges * sizeof(uint32_t));
	cudaMalloc(&this->d_edgeMultiplicity, numEdges * sizeof(uint16_t));
	cudaMalloc(&this->d_locks,           num_words * sizeof(uint64_t));
	cudaMalloc(&this->d_count_palindrome, sizeof(size_t));
	//cudaMalloc(&this->d_vertices,         239924 * 6 * sizeof(uint32_t));//revisar si no alcanza con int 32
	uint32_t cantMax_v_salida = numEdges*(0.83/100); 
	cudaMalloc(&this->d_vertices,         cantMax_v_salida * 6 * sizeof(uint32_t));//revisar si no alcanza con int 32
	cudaMalloc(&this->d_vertex_counter,   sizeof(unsigned int));
}	


/*

void SDBG::reservarMemoriaGPU_async(uint32_t numEdges) {
	//CUDA_CHECK(cudaMallocAsync(&d_isValidEdge, (size_t)numEdges * sizeof(uint8_t), stream));
	 size_t num_words = (numEdges + 63) >> 6;
	CUDA_CHECK(cudaMallocAsync(&d_isValidEdgeBits, num_words * sizeof(uint64_t), stream));
	
	CUDA_CHECK(cudaMallocAsync(&d_nextEdge,(size_t)numEdges * sizeof(uint32_t), stream));
	CUDA_CHECK(cudaMallocAsync(&d_prevEdge, (size_t)numEdges * sizeof(uint32_t), stream));
	CUDA_CHECK(cudaMallocAsync(&d_rcEdge, (size_t)numEdges * sizeof(uint32_t), stream));
	CUDA_CHECK(cudaMallocAsync(&d_edgeMultiplicity, (size_t)numEdges * sizeof(uint16_t), stream));
	CUDA_CHECK(cudaMallocAsync(&d_locks, (size_t)numEdges * sizeof(int), stream));
	CUDA_CHECK(cudaMallocAsync(&d_count_palindrome, sizeof(size_t), stream));
	uint32_t cantMax_v_salida = numEdges*(0.83/100); //antes 239924
	CUDA_CHECK(cudaMallocAsync(&d_vertices, (size_t)cantMax_v_salida * 6 * sizeof(uint32_t), stream));
	CUDA_CHECK(cudaMallocAsync(&d_vertex_counter, sizeof(unsigned int), stream));
}*/



/*void SDBG::copiarDatosGPU_async(uint32_t numEdges) {
    const size_t bytes_valid   = (size_t)numEdges * sizeof(uint8_t);
    const size_t bytes_next    = (size_t)numEdges * sizeof(uint32_t);
    const size_t bytes_prev    = (size_t)numEdges * sizeof(uint32_t);
    const size_t bytes_mult    = (size_t)numEdges * sizeof(uint16_t);
    const size_t bytes_rc      = (size_t)numEdges * sizeof(uint32_t);
    const size_t bytes_locks   = (size_t)numEdges * sizeof(int);
    uint32_t cantMax_v_salida = numEdges*(0.83/100); 
    const size_t bytes_vertices = (size_t)cantMax_v_salida * 6 * sizeof(uint32_t);

    //CUDA_CHECK(cudaMemcpyAsync(d_isValidEdge,GetHostValidEdge(),bytes_valid,cudaMemcpyHostToDevice,stream));
    size_t num_words = (numEdges + 63) >> 6;
    CUDA_CHECK(cudaMemcpyAsync(d_isValidEdgeBits, host_is_valid_edge_bits.data(),  num_words * sizeof(uint64_t),  cudaMemcpyHostToDevice,stream));
    
    CUDA_CHECK(cudaMemcpyAsync(d_nextEdge,GetHostNextEdge(),bytes_next,cudaMemcpyHostToDevice,stream));
    CUDA_CHECK(cudaMemcpyAsync(d_prevEdge,GetHostPrevEdge(),bytes_prev,cudaMemcpyHostToDevice,stream));
    CUDA_CHECK(cudaMemcpyAsync(d_edgeMultiplicity,GetHostMultiplicity(),bytes_mult,cudaMemcpyHostToDevice,stream));
    CUDA_CHECK(cudaMemcpyAsync(d_rcEdge,GetHostRcEdge(),bytes_rc,cudaMemcpyHostToDevice,stream));
    CUDA_CHECK(cudaMemsetAsync(d_locks, 0, bytes_locks, stream));
    CUDA_CHECK(cudaMemsetAsync(d_count_palindrome, 0, sizeof(size_t),stream));
    CUDA_CHECK(cudaMemsetAsync(d_vertex_counter, 0,sizeof(unsigned int),stream));
    CUDA_CHECK(cudaMemsetAsync(d_vertices,0,bytes_vertices,stream));
}*/

void SDBG::copiarDatosGPU(uint32_t numEdges) {
	//cudaMemcpy(d_isValidEdge, GetHostValidEdge(),  numEdges * sizeof(uint8_t), cudaMemcpyHostToDevice);//transferencia asincronica
	
	size_t num_words = (numEdges + 63) >> 6;
        cudaMemcpy(d_isValidEdgeBits, host_is_valid_edge_bits.data(),  num_words * sizeof(uint64_t),  cudaMemcpyHostToDevice);
    
	cudaMemcpy(d_nextEdge, GetHostNextEdge(),  numEdges * sizeof(uint32_t), cudaMemcpyHostToDevice);
	cudaMemcpy(d_prevEdge, GetHostPrevEdge(), numEdges * sizeof(uint32_t), cudaMemcpyHostToDevice);
	cudaMemcpy(d_edgeMultiplicity, GetHostMultiplicity(), numEdges * sizeof(uint16_t), cudaMemcpyHostToDevice);
	cudaMemcpy(d_rcEdge, GetHostRcEdge(), numEdges * sizeof(uint32_t), cudaMemcpyHostToDevice);

	//cudaMemset(d_locks,            0, numEdges * sizeof(int));
	cudaMemset(d_locks,            0, num_words * sizeof(uint64_t));
	cudaMemset(d_count_palindrome, 0, sizeof(size_t));
	cudaMemset(d_vertex_counter,   0, sizeof(unsigned int));
	uint32_t cantMax_v_salida = numEdges*(0.83/100); 
	cudaMemset(d_vertices,         0, cantMax_v_salida * 6 * sizeof(uint32_t));
}



    void SDBG::prepararEjecucionGPU_hallarCamSimples_Loops() {
	SimpleTimer timer;
	
	const uint32_t numEdges = size();
	
	timer.reset();
	timer.start();
	reservarMemoriaGPU(numEdges);
	timer.stop();
        xinfoc("---GPU---prepararEjecucionGPU_hallarCamSimples_Loops---Tiempo reserva memoria en GPU:{.3}\n", timer.elapsed());
	
	timer.reset();
	timer.start();


	if (numEdges == 0) {
		std::cerr << "Error: cantidad de aristas = 0. No se pudo cargar correctamente el grafo." << std::endl;
	    	return;
	}

	// Preasignar memoria
	//host_is_valid_edge.assign(numEdges, 0);
	host_is_valid_edge_bits.assign((numEdges + 63) >> 6, 0);
	host_next_edge.assign(numEdges, kNullID32-1);
	host_prev_edge.assign(numEdges, kNullID32-1);
	host_rc_edge.assign(numEdges, kNullID32);
	//host_edge_multiplicity.assign(numEdges, 0);
	
	timer.stop();
        xinfoc("---GPU---prepararEjecucionGPU_hallarCamSimples_Loops---Tiempo inicializar estructuras auxiliares:{.3}\n", timer.elapsed());
        

         // bool IsValidEdge(uint64_t edge_id) const {    return (!invalid_.at(edge_id));  }
        timer.reset();
   	timer.start();
   	
   	/*uint32_t next, prev;
   	uint16_t mult;
   	uint64_t i;
	#pragma omp parallel for private (next, prev, mult) //schedule(static)//probar con dynamic
	for (i = 0; i < numEdges; i++) {
	  // Chequeo si la arista debe marcarse como inválida por su contenido
	  if (IsValidEdge(i)) {	         
	       // host_is_valid_edge[i]= 1;
		SetHostIsValidEdge(i);

		next = NextSimplePathEdge32(i);	
	      	if (next >= numEdges) next = kNullID32;
	      	host_next_edge[i] = next;

	  	prev = PrevSimplePathEdge32(i);
		if (prev >= numEdges) prev = kNullID32;	
		host_prev_edge[i] = prev;

		if (host_edge_multiplicity[i] ==0){
		    	mult  = EdgeMultiplicity(i);
		  	host_edge_multiplicity[i] = mult;
	  	}
           }
        }*/
        

	#pragma omp parallel for schedule(dynamic, 1024)//schedule(static)//probar con dynamic
	for (uint64_t i = 0; i < numEdges; i++) {
	  // Chequeo si la arista debe marcarse como inválida por su contenido
	  if (IsValidEdge(i)) {	         
	       // host_is_valid_edge[i]= 1;
		SetHostIsValidEdge(i);

		if (host_next_edge[i] == (kNullID32-1)){
			uint32_t next = NextSimplePathEdge32(i);	
		      	if (next >= numEdges) next = kNullID32;
		      	else host_prev_edge[next] = i;
		      	host_next_edge[i] = next;
	      	}

		if (host_prev_edge[i] == (kNullID32-1)){
		  	uint32_t prev = PrevSimplePathEdge32(i);
			if (prev >= numEdges) prev = kNullID32;	
			else  host_next_edge[prev] = i;
			host_prev_edge[i] = prev;
		}

		if (host_edge_multiplicity[i] ==0){
		    	uint16_t mult  = EdgeMultiplicity(i);
		  	host_edge_multiplicity[i] = mult;
	  	}
           }
        }
        

        timer.stop();
        xinfoc("---GPU---prepararEjecucionGPU_hallarCamSimples_Loops--Tiempo cargo estructuras auxiliares isvalid, nex, prev y mult:{.3}\n", timer.elapsed());
        
        timer.reset();
   	timer.start();
   	
	LoadNeedRCForSimplePaths(this);
	
	timer.stop();
        xinfoc("---GPU---prepararEjecucionGPU_hallarCamSimples_Loops--Tiempo cargo estructura auxiliar rev comp SimplePaths:{.3}\n", timer.elapsed());
        
	timer.reset();
   	timer.start();
	
	LoadNeedRCForLoops(this); //prueba

     
        timer.stop();
        xinfoc("---GPU---prepararEjecucionGPU_hallarCamSimples_Loops--Tiempo cargo estructura auxiliar rev comp Loops:{.3}\n", timer.elapsed());
     	
	// Reserva en GPU
	/*timer.reset();
	timer.start();
	
	reservarMemoriaGPU(numEdges);
		    
	timer.stop();
	xinfo("---GPU---prepararEjecucionGPU_hallarCamSimples_Loops---tiempo reserva de memoria en GPU (cudaMalloc):{.3}\n", timer.elapsed());*/
	
	timer.reset();
	timer.start();

//	copiarDatosGPU_async(numEdges);
	copiarDatosGPU(numEdges);
	
        //copiarDatosGPU(numEdges);

	timer.stop();
	xinfo("---GPU---prepararEjecucionGPU_hallarCamSimples_Loops--Tiempo transferencia a memoria de GPU (cudaMemcpy y cudaMemset) para caminos simples:{.3}\n",timer.elapsed());

}




    
