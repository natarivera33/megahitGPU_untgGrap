#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

./recortar_fastq.sh 5000
./comparar_megahit_cpu_gpu.sh 1
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/1/final.contigs.fa /home/natalia/Tesis/test_output_gpu/1/final.contigs.fa > /home/natalia/Tesis/test_output_gpu/1/comparacionContigs.txt
./comparar_patrones.sh 1

./recortar_fastq.sh 15000
./comparar_megahit_cpu_gpu.sh 2
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/2/final.contigs.fa /home/natalia/Tesis/test_output_gpu/2/final.contigs.fa > /home/natalia/Tesis/test_output_gpu/2/comparacionContigs.txt
./comparar_patrones.sh 2

./recortar_fastq.sh 50000
./comparar_megahit_cpu_gpu.sh 3
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/3/final.contigs.fa /home/natalia/Tesis/test_output_gpu/3/final.contigs.fa > /home/natalia/Tesis/test_output_gpu/3/comparacionContigs.txt
./comparar_patrones.sh 3

./recortar_fastq.sh 70000
./comparar_megahit_cpu_gpu.sh 4
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/4/final.contigs.fa /home/natalia/Tesis/test_output_gpu/4/final.contigs.fa > /home/natalia/Tesis/test_output_gpu/4/comparacionContigs.txt
./comparar_patrones.sh 4

./recortar_fastq.sh 100000
./comparar_megahit_cpu_gpu.sh 5
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/5/final.contigs.fa /home/natalia/Tesis/test_output_gpu/5/final.contigs.fa  > /home/natalia/Tesis/test_output_gpu/5/comparacionContigs.txt
./comparar_patrones.sh 5

./recortar_fastq.sh 150000
./comparar_megahit_cpu_gpu.sh 6
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/6/final.contigs.fa /home/natalia/Tesis/test_output_gpu/6/final.contigs.fa  > /home/natalia/Tesis/test_output_gpu/6/comparacionContigs.txt
./comparar_patrones.sh 6

./recortar_fastq.sh 200000
./comparar_megahit_cpu_gpu.sh 7
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/7/final.contigs.fa /home/natalia/Tesis/test_output_gpu/7/final.contigs.fa  > /home/natalia/Tesis/test_output_gpu/7/comparacionContigs.txt
./comparar_patrones.sh 7

./recortar_fastq.sh 250000
./comparar_megahit_cpu_gpu.sh 8
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/8/final.contigs.fa /home/natalia/Tesis/test_output_gpu/8/final.contigs.fa  > /home/natalia/Tesis/test_output_gpu/8/comparacionContigs.txt
./comparar_patrones.sh 8


./recortar_fastq.sh 300000
./comparar_megahit_cpu_gpu.sh 9
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/9/final.contigs.fa /home/natalia/Tesis/test_output_gpu/9/final.contigs.fa  > /home/natalia/Tesis/test_output_gpu/9/comparacionContigs.txt
./comparar_patrones.sh 9

./recortar_fastq.sh 350000
./comparar_megahit_cpu_gpu.sh 10
./comparar_contigs.sh /home/natalia/Tesis/test_output_orig/10/final.contigs.fa /home/natalia/Tesis/test_output_gpu/10/final.contigs.fa  > /home/natalia/Tesis/test_output_gpu/10/comparacionContigs.txt
./comparar_patrones.sh 10


python3 "$SCRIPT_DIR/unir_patrones.py"


