#!/bin/bash
#INPUT_FASTQ1="/home/natalia/Tesis/Datos/galaxy/peq1.fastq.gz"             # tu input pequeño
#INPUT_FASTQ2="/home/natalia/Tesis/Datos/galaxy/peq2.fastq.gz"             # tu input pequeño
#INPUT_FASTQ1="/home/natalia/Tesis/Datos/Paper/SRR341725_1.fastq.gz"             # grande
#INPUT_FASTQ2="/home/natalia/Tesis/Datos/Paper/SRR341725_2.fastq.gz"             #grande

# Definí las rutas
MEGAHIT_GPU="../megahit/build/megahit"         # tu versión modificada
#MMEGAHIT_ORIGINAL="../../ultima_descarga/megahit/build/megahit"

MEGAHIT_ORIGINAL="../megahit-descargado/megahit/build/megahit" # la versión oficial
#MEGAHIT_ORIGINAL="/home/natalia/megahit-descargado/megahit-cambios-buscando-determinismo/build/megahit"

INPUT_FASTQ1="/home/natalia/Tesis/Datos/Recortados/mini1.fastq.gz"
INPUT_FASTQ2="/home/natalia/Tesis/Datos/Recortados/mini2.fastq.gz"
# INPUT_FASTQ1="/home/natalia/Tesis/Datos/1-2-9/r3_1.fa"
# INPUT_FASTQ2="/home/natalia/Tesis/Datos/1-2-9/r3_2.fa"

#INPUT_FASTQ1="/home/natalia/Tesis/Datos/Recortados/reads_1.fastq"
#INPUT_FASTQ2="/home/natalia/Tesis/Datos/Recortados/reads_2.fastq"


WORKDIR="test_output"
NRO_EJECUCION="${1:-1}"

echo "🔢 Número de ejecución: $NRO_EJECUCION"
OUT_DIR="./comparaciones_logs"
mkdir -p "$OUT_DIR"

# Crear carpetas de trabajo separadas
#rm -rf "$WORKDIR"_orig 
#mkdir "$WORKDIR"_orig 
#rm -rf "$WORKDIR"_gpu 
#mkdir "$WORKDIR"_gpu

rm  -rf "$WORKDIR"_gpu/"$NRO_EJECUCION"
rm  -rf "$WORKDIR"_orig/"$NRO_EJECUCION" 

# Ejecutar tu MEGAHIT adaptado a GPU
echo "🚀 Corriendo MEGAHIT GPU..."
#$MEGAHIT_GPU -1 "$INPUT_FASTQ1" -2 "$INPUT_FASTQ2" -o "$WORKDIR"_gpu/"$NRO_EJECUCION" 

#$MEGAHIT_GPU -1 "$INPUT_FASTQ1" -2 "$INPUT_FASTQ2" -o "$WORKDIR"_gpu/"$NRO_EJECUCION" --min-count 1 --k-min 21 --k-max 81 --k-step 10  --k-max 131  --num-cpu-threads 1 --no-mercy
$MEGAHIT_GPU -1 "$INPUT_FASTQ1" -2 "$INPUT_FASTQ2" -o "$WORKDIR"_gpu/"$NRO_EJECUCION"

# Ejecutar MEGAHIT original
echo "🚀 Corriendo MEGAHIT Original..."
#$MEGAHIT_ORIGINAL -1 "$INPUT_FASTQ1" -2 "$INPUT_FASTQ2" -o "$WORKDIR"_orig/"$NRO_EJECUCION"   --k-max 131  --num-cpu-threads 1 --no-mercy
$MEGAHIT_ORIGINAL -1 "$INPUT_FASTQ1" -2 "$INPUT_FASTQ2" -o "$WORKDIR"_orig/"$NRO_EJECUCION"


# echo ""
# echo "🧹 Comparando cantidad de contigs finales..."
# echo "----------------------------------GPU----------------------------------"
# grep -i "contigs" "$WORKDIR"_gpu/"$NRO_EJECUCION"/log
# echo "----------------------------------ORIG----------------------------------"
# grep -i "contigs" "$WORKDIR"_orig/"$NRO_EJECUCION"/log



#echo ""
#echo "🧹 Comparando cantidad de caminos en logs..."
#echo "----------------------------------GPU----------------------------------"
#grep -i "caminos" "$WORKDIR"_gpu/"$NRO_EJECUCION"/log | sed "s/^b'//;s/'$//;s/\\\xe2\\\x9c\\\x85/✅/" || true
#echo ""
#echo "----------------------------------ORIG----------------------------------"
#grep -i "caminos" "$WORKDIR"_orig/"$NRO_EJECUCION"/log | sed "s/^b'//;s/'$//;s/\\\xe2\\\x9c\\\x85/✅/" || true
#echo ""


# echo ""
# echo "🧹 Comparando cantidad de caminos en logs..."
# echo "----------------------------------GPU LOOP----------------------------------"
# grep -i "loop" "$WORKDIR"_gpu/"$NRO_EJECUCION"/log
# echo "----------------------------------ORIG LOOP----------------------------------"
# grep -i "loop" "$WORKDIR"_orig/"$NRO_EJECUCION"/log



echo ""
echo "🧹 Cantidad de lineas en archivo de contigs salida"
echo "----------------------------------GPU----------------------------------"
wc -l "$WORKDIR"_gpu/"$NRO_EJECUCION"/final.contigs.fa
echo "----------------------------------ORIG----------------------------------"
wc -l "$WORKDIR"_orig/"$NRO_EJECUCION"/final.contigs.fa





# Quitamos los headers (líneas que empiezan con '>') y ordenamos
grep -v '^>'  "$WORKDIR"_gpu/"$NRO_EJECUCION"/final.contigs.fa | sort >  contigs_gpu.txt
grep -v '^>'  "$WORKDIR"_orig/"$NRO_EJECUCION"/final.contigs.fa | sort > contigs_orig.txt

# Comparamos los contenidos ordenados
diff contigs_gpu.txt contigs_orig.txt > diferencias.diff
if [ -s diferencias.diff ]; then
    echo "❗ Hay diferencias entre los contigs."
    #echo "----------------------------------GPU----------------------------------"
    #cat "$WORKDIR"_gpu/"$NRO_EJECUCION"/final.contigs.fa 
    #echo "----------------------------------ORIGINAL----------------------------------"
    #cat "$WORKDIR"_orig/"$NRO_EJECUCION"/final.contigs.fa 
else
    echo "✅ Los contigs son idénticos."
   #     echo "----------------------------------GPU----------------------------------"
    #cat "$WORKDIR"_gpu/"$NRO_EJECUCION"/final.contigs.fa 
   # echo "----------------------------------ORIGINAL----------------------------------"
   # cat "$WORKDIR"_orig/"$NRO_EJECUCION"/final.contigs.fa 
fi

./comparar_contigs.sh  "$WORKDIR"_orig/"$NRO_EJECUCION"/final.contigs.fa  "$WORKDIR"_gpu/"$NRO_EJECUCION"/final.contigs.fa 


