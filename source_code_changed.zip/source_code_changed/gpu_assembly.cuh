#pragma once

#include <cstdint>

// Wrappers host para lanzar kernels desde C++ (unitig_graph.cpp).
// unitig_graph.cpp NO debe ver __global__ ni <<<>>>.

void GPU_procesarCaminosSimples(
    uint64_t* d_isValidEdgeBits, uint32_t* d_nextEdge, uint32_t* d_prevEdge,
    uint32_t* d_rcEdge, uint16_t* d_edgeMultiplicity, uint32_t numEdges,
    int* d_count_palindrome, uint64_t* d_locks,
    uint32_t* d_vertices, unsigned int* d_vertex_counter,
    int blockSize/*, cudaStream_t stream*/);

void GPU_procesarLoops(
    uint64_t* d_isValidEdgeBits, uint32_t* d_prevEdge, uint32_t* d_nextEdge,
    uint32_t* d_rcEdge, uint16_t* d_edgeMultiplicity,
    uint64_t* d_locks, uint32_t numEdges,
    uint32_t* d_vertices, unsigned int* d_vertex_counter,
    int blockSize/*, cudaStream_t stream*/);
/*
void GPU_marcarNeedRC_SimplePaths(
    const uint8_t* d_isValidEdge,
    const uint64_t* d_nextEdge,
    const uint64_t* d_prevEdge,
    uint64_t numEdges,
    char* d_need_rc,int * d_locks, int blockSize);

void GPU_marcarNeedRC_Loops(
    const uint8_t* d_isValidEdge,
    const uint64_t* d_prevEdge,
    uint64_t numEdges,
    char* d_need_rc,int * d_locks, int blockSize);

// kernels *_rc (los que llenan d_calcRC / d_calcRC_vertex)
void GPU_procesarCaminosSimples_rc(
    uint8_t* d_isValidEdge, uint64_t* d_nextEdge, uint64_t* d_prevEdge,
    uint64_t* d_rcEdge, int64_t* d_edgeMultiplicity, uint64_t numEdges,
    int* d_count_palindrome, int* d_locks,
    uint64_t* d_calcRC, unsigned int* d_calcRC_vertex,
    int blockSize);

void GPU_procesarLoops_rc(
    uint8_t* d_isValidEdge, uint64_t* d_prevEdge, uint64_t* d_nextEdge,
    uint64_t* d_rcEdge, int64_t* d_edgeMultiplicity,
    int* d_locks, uint64_t numEdges,
    uint64_t* d_calcRC, unsigned int* d_calcRC_vertex,
    int blockSize);
*/
// Opcional para debug
void GPU_checkLastCuda(const char* where);
